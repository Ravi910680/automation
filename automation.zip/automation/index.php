
<?php
session_start();

$_SESSION['id']="497889959";

$id=$_SESSION['id'];
$email=$_SESSION['email'];

?>






<html><head>


<link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=Lato:ital,wght@0,100;0,300;0,400;0,700;0,900;1,100;1,300;1,400;1,700;1,900&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
<link href="https://res.cloudinary.com/dbkkxj00u/raw/upload/v1601356785/font-owsome/all_epmuwn.css" rel="stylesheet">
<link rel="stylesheet" type="text/css" href="https://res.cloudinary.com/dbkkxj00u/raw/upload/v1628745601/loader_ww3kdih.css">
<style type="text/css">


.sd-con-ico.dsc-inln-flx {
    width: 8%;
    height: 100%;
}

.main-con-of-crm.dsc-inln-flx {
    width: 92%;
    height: 100%;
    float: right;
    background: #fafafa;
    overflow: scroll;
}

    .dsc-inln-flx {
    display: inline-block;
}

.sd-hd-con {
    height: 10vh;
    text-align: center;
    }

    .icon-con-of-sd {
    height: 90vh;
    width: 100%;
}

.icon-main-con {
    height: auto;
    width: 100%;
    position: relative;
    top: 50%;
    -ms-transform: translateY(-50%);
    transform: translateY(-50%);
    }

    .con-ico {
    padding: 20px;
    text-align: center;
}

img.con-of-ico-img {
    height: 30px;
    }




.con-of-main-splt {
    width: 20%;
    height: 100vh;
    display: inline-block;

}
.sd-hd-con {
    height: 10vh;
    text-align: center;
    }

   
h2.head-od-dt-shw {
    margin: 0px;
    }


button.btn-of-drk-back {
    height: 6vh;
    width: 100%;
    background: #125ef6;
    border: 0px;
    border-radius: 5px;
    color: white;
}

.con-of-dt-sel-ele {
    height: 80vh;
    width: 100%;
    overflow: scroll;
    }

    .container-2GnNH {
    display: -webkit-box;
    display: -ms-flexbox;
    display: flex;
    -webkit-box-orient: horizontal;
    -webkit-box-direction: normal;
    -ms-flex-direction: row;
    flex-direction: row;
    -webkit-box-align: center;
    -ms-flex-align: center;
    align-items: center;
    padding: 15px;
}
a.com-for-lnk {
    text-decoration: none;
    color: black;
    }

    h2.head-od-dt-shw {
    margin: 0px;
    font-family: lato;
    font-size: 15px;
    font-weight: bolder;
}
.con-of-main-splt {
    width: 20%;
    height: 100vh;
    background: #e5eafc30;
    }


    .eml-add-main-con {
    width: 29%;
    height: 100vh;
    display: inline-block;
    vertical-align: top;
    margin: 0;
    padding: 0;
    font-size: 16px;
    
}

.sd-hd-con {
    height: 10vh;
    text-align: center;
    }
    input.srch-ip-fld {
    width: 100%;
    height: 3vh;
    border: none;
    font-family: 'Lato';
    font-weight: 500;
    color: #c7ccd7;
}
.con-of-full-email-dt {
    width: 100%;
    height: 90vh;
    }

    .img-eml-ico-con {
    font-family: 'Lato';
    padding: 15px;
    border-radius: 50%;
    background: pink;
    margin-right: 10px;
    color: #ca1938;
}
.sub-ln-of-email-txt {
    width: 240px;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
    font-family: 'Lato';
    color: #908c8c;
    font-size: 13px;
}
input.srch-ip-fld:focus{
    outline: none;
    border: none;
}

    .fnt-ico-sel {
    width: 20px;
    text-align: center;
}

.con-of-cht-usr {
    width: 50%;
    display: inline-block;
    height: 100vh;
    display: inline-block;
    vertical-align: top;
    margin: 0;
    padding: 0;
    border-left: 1px solid #f2f2f2;
    }





.con-ico:hover{
    cursor: pointer;
}

.head-of-dash{
    background: #4a154b;
    text-align: right;
    border-bottom-left-radius: 50px;
}


.dropdown-menu .dropdown-item {
    padding: .5rem 1rem;
    font-size: 13px;
    font-weight: 600;
}

button.dropdown-item.comm_up_btn:hover {
    background: #0d66d6;
    color: white;
    }

    .dropdown-header {
    padding: .5rem 1rem;
    color: #f6f9fc;
    font-size: .625rem;
    text-transform: uppercase;
    font-weight: 700;
}
.dropdown-header {
    display: block;
    padding: .5rem 1rem;
    margin-bottom: 0;
    font-size: 0.875rem;
    color: #8898aa;
    white-space: nowrap;
    }
    .dropdown-menu {
    padding: 10px !important;
    box-shadow: rgb(50 50 93 / 25%) 0px 2px 5px -1px, rgb(0 0 0 / 30%) 0px 1px 3px -1px !important;
}

.dropdown-item {
    border-radius: 10px;
    }

h6, .h6 {
    font-size: 0.625rem !important;
}


.head-of-inn-con {
    padding: 24px;
}
.all-auta-con {
    padding: 0px 24px;
    }
    span.nm-auta-con {
    font-size: 16px;
    font-weight: 500;
    font-family: 'lato';
    color: #00000080;
}

.crt-new-auta-con {
    width: 200px;
    background: rgb(4, 135, 175);
    padding: 24px 16px;
    border-radius: 10px;
    height: 250px;
    margin-right: 30px;
    margin-top: 20px;
}

    .new-crt-head {
    line-height: 28px;
    font-weight: 700;
    color: white;
    font-family: 'Lato';
}
.con-of-crt-new-img {
    text-align: center;
    width: min-content;
    margin-top: 60px;
    padding: 10px;
    margin-left: auto;
    margin-right: auto;
    border-radius: 50%;
    box-shadow: rgb(0 0 0 / 8%) 0px 2px 4px, rgb(0 0 0 / 6%) 0px 2px 12px, rgb(0 0 0 / 4%) 0px 8px 14px, rgb(0 0 0 / 2%) 0px 12px 16px;
    }

    .crt-new-auta-con:hover{
cursor: pointer;
    }

    .auta-dis-on-dash {
    width: 200px;
    padding: 24px 16px;
    border-radius: 10px;
    background: white;
    margin-right: 30px;
    height: 250px;
    padding-bottom: 0px;
    box-shadow: rgb(0 0 0 / 8%) 0px 2px 4px, rgb(0 0 0 / 6%) 0px 2px 12px;
    transition: .3s;
    margin-top: 20px;
}

.auta-dis-on-dash:hover{
    box-shadow: rgb(0 0 0 / 8%) 0px 2px 4px, rgb(0 0 0 / 6%) 0px 2px 12px, rgb(0 0 0 / 4%) 0px 8px 14px, rgb(0 0 0 / 2%) 0px 12px 16px;
cursor: pointer;

}
.main-con-name {
    flex: auto;
    min-height: 166px;
    display: inline-grid;
    width: 100%;
    }
    
    span.bdg-tp-btn {
    margin-left: auto;
    font-size: 12px;
    background: rgb(245, 249, 248);
    padding: 2px 10px;
    border-radius: 10px;
    color: rgb(2, 80, 65);
    font-family: 'Lato';
    font-weight: 600;
    letter-spacing: .4px;
    height: fit-content;
}
.def-name-con-crd {
    justify-content: center;
    flex-direction: column;
    display: flex;
    margin: auto;
    font-family: 'Lato';
    }
    .def_stat-of-dt {
    padding: 16px 0px;
    display: inline-flex;
    width: 100%;
    height: 60px;
}
.def_stat-of-dt > div {
    font-size: 14px;
    height: fit-content;
    
}
    .con-of-cnt-data {
    padding: 5.5px 10px;
    background: rgba(0, 0, 0, 0.07);
    border-radius: 5px;
    color: rgb(38, 38, 39);
    width: 60%;
    text-align: center;
    text-overflow: ellipsis;
    overflow: hidden;
    white-space: nowrap;
}
.def_stat-of-dt > div {
    font-size: 14px;
    height: fit-content;
    }

    .con-of-dp-data {
    width: 40%;
}

button#dropdownMenuButton {
    background: no-repeat;
    border: none;
    height: 32px;
    padding: 5.5px;
    float: right;
    }

.all-auta-con {
    padding: 0px 24px;
    display: inline-flex;

}
.dropdown-toggle::after{
    display: none;
}

.dropdown-menu.show{
    border: none;
    border-radius: 10px;
}

a.com-for-lnk {
    text-decoration: none;
    color: #00000091;
    }
    .marg-for-temp{
        margin-left: 0px;
        margin-right: 30px;
    }
    .img-temp-of-mark{
        width: 168px;
        height: 166px;
    }










  .ip-by-def-dsg {
    width: 100%;
    background-color: #FFFFFF;
    height: 48px;
    padding-left: 16px;
    padding-right: 16px;
    border-radius: 4px;
    margin: 8px 0px;
    border: 1px solid #B8B8B8;
    font-weight: 400;
    font-size: 14px;
    text-align: left;
    box-sizing: border-box;
    -webkit-transition-property: border-width,border-color,box-shadow;
    transition-property: border-width,border-color,box-shadow;
    -webkit-transition-duration: 0.1s;
    transition-duration: 0.1s;
    -webkit-transition-timing-function: ease-in;
    transition-timing-function: ease-in;
    box-shadow: 2px 2px 0 2px transparent;
    text-overflow: ellipsis;
    overflow: hidden;


  }

  .ip-by-def-dsg:focus {
    background-color: #fff;
    outline: 0;
    border-color: #524d52;
    box-shadow: 0 0 0 3px #bdb2bd4d;

    -webkit-transition-property: border-width,border-color,box-shadow;
    transition-property: border-width,border-color,box-shadow;
    -webkit-transition-duration: 0.1s;
    transition-duration: 0.1s;
    -webkit-transition-timing-function: ease-in;
    transition-timing-function: ease-in;

  }



button:disabled,
button[disabled]{
  border: 1px solid #999999;
  background-color: #cccccc;
  color: #666666;
  border: none;
  cursor: not-allowed;
}

.btn-blck-in-auta-fcs{
    display: inline-flex;
    -webkit-box-align: center;
    align-items: center;
    -webkit-box-pack: center;
    justify-content: center;
    background-color: rgb(38, 38, 39);
    color: rgb(255, 255, 255);
    position: relative;
    outline: none;
    font-family: inherit;
    border: 0px;
    transition: all 0.4s ease 0s;
    cursor: pointer;
    white-space: nowrap;
    text-decoration: none;
    border-radius: 4px;
    padding: 6px 12px;
    min-height: 32px;
    font-size: 14px;
    line-height: 20px;
    font-family: 'lato';
}

.btn-blck-in-auta-fcs:hover{
    background-color: rgb(71, 71, 71);
    transition: all 0.2s ease 0s;
}

.btn-blck-non-fcs{
    display: inline-flex;
    -webkit-box-align: center;
    align-items: center;
    -webkit-box-pack: center;
    justify-content: center;
    background-color: rgb(227, 227, 227);
    color: rgb(38, 38, 39);
    position: relative;
    outline: none;
    font-family: inherit;
    border: 0px;
    transition: all 0.4s ease 0s;
    cursor: pointer;
    white-space: nowrap;
    text-decoration: none;
    border-radius: 4px;
    padding: 6px 12px;
    min-height: 32px;
    font-size: 14px;
    line-height: 20px;
}

.btn-blck-non-fcs:hover{
    background-color: rgb(231, 231, 231);
    transition: all 0.2s ease 0s;
    color: black;
}

.modal-content{
    border-radius: 8px;
}

.btn-blck-non-fcs:focus{
    color: #fff;
    background-color: #313335 !important;
    border-color: #3d3e40 !important;
    box-shadow: 0 0 0 0.2rem rgb(68 70 72 / 50%) !important;
}
.btn-blck-non-fcs:active{

color: #fff;
    background-color: #313335 !important;
    border-color: #3d3e40 !important;
    box-shadow: 0 0 0 0.2rem rgb(68 70 72 / 50%) !important;

}


.con-of-temp-lst {
    display: inline-flex;
    width: 100%;
    padding: 5px 10px;
    border-radius: 10px;
    margin-bottom: 10px;
    }

    .con-of-temp-lst:hover {
    background: #f2f2f28a;
    cursor: pointer;
}

.con-of-temp-lst>div {
    width: 50%;
    }

    span.temp-name {
    font-size: 14px;
}

span.crt-data-of-tmp {
    font-size: 10px;
    }
.row{
    margin-left: 0px;
    margin-right: 0px;
}








.btn-primary.focus, .btn-primary:focus{

    color: #fff;
    box-shadow: 0 0 0 0.2rem rgb(105 109 113 / 50%);
    background-color: rgb(38, 38, 39);
    border-color: rgb(38, 38, 39);

}





.err-menu-cls-dsg{

transition:.2s;
  top: auto !important;
    width: fit-content;
    bottom: 10vh !important;
    padding: 10px;
    background: #000000b5;
    font-size: 13px;
    border-radius: 5px;
    z-index: 100;
    color: white !important;
    display: none;
    z-index: 100000000;
}

#cncl-err-msg:hover{


cursor: pointer;


}



.vert-cent-div {
 
  height: min-content;
  text-align: center;
  
  position: absolute;
  top:0;
  bottom: 0;
  left: 0;
  right: 0;
    
  margin: auto;
}


</style>

<script src="http://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
</head>

<body style="
    margin: 0px;
">





<div class="vert-cent-div err-menu-cls-dsg" id="err_msg_dt_trg" style="display: none;">
<span id="con-of-err-msg"></span>
<span class="cls-err-menu" id="cncl-err-msg">
<i class="fal fa-times-circle" style="
    padding: 6px;
"></i>
</span>
</div>


<div class="main-con-of-dash">
<style>


#main-loader-containre-act{


    text-align: center;
    padding-top: 41vh;
  }

.main-loader-containre-act{
  text-align: center;padding-top: 41vh;height: 84vh;
}


.cp-round:after{
        border-top: solid 3px #564f4e;


    }

</style>
    
    <div class="sd-con-ico dsc-inln-flx" style="
">
    
    <div class="sd-hd-con"><img src="https://res.cloudinary.com/heptera/image/upload/v1611850905/landing/open-collective_1_m4opwf.svg" width="" style="
    padding: 2vh
    ">
</div>

<div class="icon-con-of-sd">

    <div class="icon-main-con">
<div class="con-ico com-for-lnk" data-for-serv="0" data-target-link="https://campign.auftera.com/campigns/all-campign" data-toggle="tooltip" data-placement="right" title="Sheduled Campigns"><img class="con-of-ico-img" src="https://res.cloudinary.com/heptera/image/upload/v1626278281/automation/schedule_send_black_24dp_wybxtb.svg"></div>
<div class="con-ico com-for-lnk" data-for-serv="1" data-path-ses="contact/" data-target-link="https://contact.auftera.com/contact/#acl" data-toggle="tooltip" data-placement="right" title="Manage Contact List"><img class="con-of-ico-img" src="https://res.cloudinary.com/heptera/image/upload/v1628748461/email-crm/playlist_add_circle_black_24dp_eryixo.svg"></div>
<div class="con-ico com-for-lnk" data-for-serv="1" data-path-ses="template/" data-target-link="https://template.auftera.com/template/" data-toggle="tooltip" data-placement="right" title="Manage Template"><img class="con-of-ico-img" src="https://res.cloudinary.com/heptera/image/upload/v1626278301/automation/web_black_24dp_kx5cze.svg"></div>
<div class="con-ico com-for-lnk" data-for-serv="1" data-path-ses="studio/" data-target-link="https://studio.auftera.com/studio/" data-toggle="tooltip" data-placement="right" title="Browse Studio"><img class="con-of-ico-img" src="https://res.cloudinary.com/heptera/image/upload/v1626278284/automation/camera_black_24dp_ldwdgu.svg"></div>
<div class="con-ico" data-toggle="tooltip" data-placement="right" title="Launch Automation"><img class="con-of-ico-img" src="https://res.cloudinary.com/heptera/image/upload/v1627707060/automation/model_training_black_24dp_wjuu9i.svg"></div>
<div class="con-ico com-for-lnk" data-for-serv="1" data-path-ses="social/" data-target-link="https://social.auftera.com/social/" data-toggle="tooltip" data-placement="right" title="Social Post"><img class="con-of-ico-img" src="https://res.cloudinary.com/heptera/image/upload/v1627537307/automation/share_black_24dp_wpgnni.svg"></div>
</div>


<script>


id='<?php echo $id;?>';
email='<?php echo $email;?>';

$(document).on('click','.com-for-lnk',function(){



$("#main-loader-containre").addClass("main-loader-containre-act");
$("#main-loader-containre").html('<div class="cp-spinner cp-round"></div>');

url_lnk=$(this).attr('data-target-link');
ses_path=$(this).attr('data-path-ses');


var sourceString = url_lnk.replace('http://','').replace('https://','').replace('www.','').split(/[/?#]/)[0];

if($(this).attr('data-for-serv')=='1'){

red_url="https://"+sourceString+"/"+ses_path+"confige/crt_ses.php?id="+id+"&email="+email+"&url_red="+url_lnk;

console.log(red_url);


}else if($(this).attr('data-for-serv')=='0'){



red_url=$(this).attr('data-target-link');





}

console.log(red_url);
window.location.href=red_url;


})
</script>

</div>


        
    
    </div>
    <div class="main-con-of-crm dsc-inln-flx">
        <div class='head-of-dash'>







<div class="dropdown" style="
    height: 8vh;
"> 
    <button class="btn btn-secondary dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" style="
    height: 8vh;
"> 
       <svg width="30" height="30" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" style="color:white;"><path d="M7 7H9V9H7V7Z" fill="currentColor"></path><path d="M11 7H13V9H11V7Z" fill="currentColor"></path><path d="M17 7H15V9H17V7Z" fill="currentColor"></path><path d="M7 11H9V13H7V11Z" fill="currentColor"></path><path d="M13 11H11V13H13V11Z" fill="currentColor"></path><path d="M15 11H17V13H15V11Z" fill="currentColor"></path><path d="M9 15H7V17H9V15Z" fill="currentColor"></path><path d="M11 15H13V17H11V15Z" fill="currentColor"></path><path d="M17 15H15V17H17V15Z" fill="currentColor"></path></svg>
    </button> 
    <div class="dropdown-menu dropdown-menu-right" x-placement="bottom-end" style="position: absolute; transform: translate3d(905px, 53px, 0px); top: 0px; left: 0px; will-change: transform;">
<div class=" dropdown-header noti-title">
<h6 class="text-overflow m-0">admin@auftera.com</h6>
</div>
<button class="dropdown-item comm_up_btn com-for-lnk" data-for-serv="1" data-path-ses="account/" data-target-link="https://account.auftera.com/account/sites/add_sites/">
<svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M6 8C6.74028 8 7.38663 7.5978 7.73244 7H14C15.1046 7 16 7.89543 16 9C16 10.1046 15.1046 11 14 11H10C7.79086 11 6 12.7909 6 15C6 17.2091 7.79086 19 10 19H16.2676C16.6134 19.5978 17.2597 20 18 20C19.1046 20 20 19.1046 20 18C20 16.8954 19.1046 16 18 16C17.2597 16 16.6134 16.4022 16.2676 17H10C8.89543 17 8 16.1046 8 15C8 13.8954 8.89543 13 10 13H14C16.2091 13 18 11.2091 18 9C18 6.79086 16.2091 5 14 5H7.73244C7.38663 4.4022 6.74028 4 6 4C4.89543 4 4 4.89543 4 6C4 7.10457 4.89543 8 6 8Z" fill="currentColor"></path></svg>
<span class="padding-left:10px;">
Connected App </span></button>
<button class="dropdown-item comm_up_btn com-for-lnk" data-for-serv="1" data-path-ses="account/" data-target-link="https://account.auftera.com/account/sender/add_sender/">
<svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" clip-rule="evenodd" d="M16 9C16 11.2091 14.2091 13 12 13C9.79086 13 8 11.2091 8 9C8 6.79086 9.79086 5 12 5C14.2091 5 16 6.79086 16 9ZM14 9C14 10.1046 13.1046 11 12 11C10.8954 11 10 10.1046 10 9C10 7.89543 10.8954 7 12 7C13.1046 7 14 7.89543 14 9Z" fill="currentColor"></path><path fill-rule="evenodd" clip-rule="evenodd" d="M12 1C5.92487 1 1 5.92487 1 12C1 18.0751 5.92487 23 12 23C18.0751 23 23 18.0751 23 12C23 5.92487 18.0751 1 12 1ZM3 12C3 14.0902 3.71255 16.014 4.90798 17.5417C6.55245 15.3889 9.14627 14 12.0645 14C14.9448 14 17.5092 15.3531 19.1565 17.4583C20.313 15.9443 21 14.0524 21 12C21 7.02944 16.9706 3 12 3C7.02944 3 3 7.02944 3 12ZM12 21C9.84977 21 7.87565 20.2459 6.32767 18.9878C7.59352 17.1812 9.69106 16 12.0645 16C14.4084 16 16.4833 17.1521 17.7538 18.9209C16.1939 20.2191 14.1881 21 12 21Z" fill="currentColor"></path></svg>
<span class="padding-left:10px;">
Sender Profile</span></button>
<button class="dropdown-item comm_up_btn com-for-lnk" data-for-serv="1" data-path-ses="account/" data-target-link="https://account.auftera.com/account/smtp/add_smtp/">
<svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M9 6C8.44772 6 8 6.44772 8 7C8 7.55228 8.44772 8 9 8H15C15.5523 8 16 7.55228 16 7C16 6.44772 15.5523 6 15 6H9Z" fill="currentColor"></path><path d="M9 10C8.44772 10 8 10.4477 8 11C8 11.5523 8.44772 12 9 12H15C15.5523 12 16 11.5523 16 11C16 10.4477 15.5523 10 15 10H9Z" fill="currentColor"></path><path d="M13 17C13 17.5523 12.5523 18 12 18C11.4477 18 11 17.5523 11 17C11 16.4477 11.4477 16 12 16C12.5523 16 13 16.4477 13 17Z" fill="currentColor"></path><path fill-rule="evenodd" clip-rule="evenodd" d="M4 5C4 3.34315 5.34315 2 7 2H17C18.6569 2 20 3.34315 20 5V19C20 20.6569 18.6569 22 17 22H7C5.34315 22 4 20.6569 4 19V5ZM7 4H17C17.5523 4 18 4.44772 18 5V19C18 19.5523 17.5523 20 17 20H7C6.44772 20 6 19.5523 6 19V5C6 4.44772 6.44771 4 7 4Z" fill="currentColor"></path></svg>
<span class="padding-left:10px;">
SMTP Server </span></button>
<button class="dropdown-item comm_up_btn com-for-lnk" data-for-serv="0" data-path-ses="contact/" data-target-link="https://contact.auftera.com/contact/emb/">
<svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" clip-rule="evenodd" d="M9 3H3V9H5V5H9V3ZM3 21V15H5V19H9V21H3ZM15 3V5H19V9H21V3H15ZM19 15H21V21H15V19H19V15ZM7 7H11V11H7V7ZM7 13H11V17H7V13ZM17 7H13V11H17V7ZM13 13H17V17H13V13Z" fill="currentColor"></path></svg><span class="padding-left:10px;">
Integration </span></button>
<button class="dropdown-item comm_up_btn com-for-lnk" data-for-serv="1" data-path-ses="dev/" data-target-link="https://dev.auftera.com/dev/">
<svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M4 14V20H10V18H6V14H4Z" fill="currentColor"></path><path fill-rule="evenodd" clip-rule="evenodd" d="M9 9V15H15V9H9ZM13 11H11V13H13V11Z" fill="currentColor"></path><path d="M4 10V4H10V6H6V10H4Z" fill="currentColor"></path><path d="M20 10V4H14V6H18V10H20Z" fill="currentColor"></path><path d="M20 14V20H14V18H18V14H20Z" fill="currentColor"></path></svg>
<span class="padding-left:10px;">
API</span></button>
<div class="dropdown-divider"></div>
<button class="dropdown-item comm_up_btn" data-for-serv="1" data-target-link="http://account.auftera.com/logout/">
<svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" clip-rule="evenodd" d="M11 19V22H13V19H14C16.2091 19 18 17.2091 18 15C18 12.7909 16.2091 11 14 11H13V7H15V9H17V5H13V2H11V5H10C7.79086 5 6 6.79086 6 9C6 11.2091 7.79086 13 10 13H11V17H9V15H7V19H11ZM13 17H14C15.1046 17 16 16.1046 16 15C16 13.8954 15.1046 13 14 13H13V17ZM11 11V7H10C8.89543 7 8 7.89543 8 9C8 10.1046 8.89543 11 10 11H11Z" fill="currentColor"></path></svg>
<span class="padding-left:10px;">
Plan</span></button>
<button class="dropdown-item comm_up_btn com" data-for-serv="1" data-target-link="http://account.auftera.com/logout/">
<svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M8.51428 20H4.51428C3.40971 20 2.51428 19.1046 2.51428 18V6C2.51428 4.89543 3.40971 4 4.51428 4H8.51428V6H4.51428V18H8.51428V20Z" fill="currentColor"></path><path d="M13.8418 17.385L15.262 15.9768L11.3428 12.0242L20.4857 12.0242C21.038 12.0242 21.4857 11.5765 21.4857 11.0242C21.4857 10.4719 21.038 10.0242 20.4857 10.0242L11.3236 10.0242L15.304 6.0774L13.8958 4.6572L7.5049 10.9941L13.8418 17.385Z" fill="currentColor"></path></svg>
<span class="padding-left:10px;">
Log Out</span></button>
</div>
 </div>









        </div>

     
<div id='main-loader-containre'>

       
    
 <div class="main-auta-con "  >
    
    <div class="head-of-inn-con">
        <span class="nm-auta-con">My Automation</span>
    
    </div>


<div class="all-auta-con row" id="dyn_con_of_all_auta">

    <div class="crt-new-auta-con" data-toggle="modal" data-target="#crt_new_auta">
        
        <div class="new-crt-head">
        
        New Automation
        </div>
        <div class="con-of-crt-new-img" style="
">
        <svg class="SVGInline-svg" style="width: 14px;height: 14px;fill: rgb(255, 255, 255);" width="10" height="10" viewBox="0 0 10 10" fill="none" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" clip-rule="evenodd" d="M0 6c0-1.10457.89543-2 2-2h8c0 1.10457-.89543 2-2 2H0z"></path><path fill-rule="evenodd" clip-rule="evenodd" d="M6 0v8c0 1.10457-.89543 2-2 2V2c0-1.104569.89543-2 2-2z"></path></svg>
        </div>
    
    
    </div>


    


</div>
    
    
</div>


<div class="auta-temp-name">

<div class="head-of-inn-con">
        <span class="nm-auta-con">Automation Template</span>
    
    </div>


<div class="all-auta-con row" id="all_con_of_temp_data">



<div class="crt-new-auta-con" data-toggle="modal" data-target="#add_temp_in_auta" style="
    background: #8a0f85;
">
        
        <div class="new-crt-head">
        
        New Automation Template
        </div>
        <div class="con-of-crt-new-img" style="
">
        <svg class="SVGInline-svg" style="width: 14px;height: 14px;fill: rgb(255, 255, 255);" width="10" height="10" viewBox="0 0 10 10" fill="none" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" clip-rule="evenodd" d="M0 6c0-1.10457.89543-2 2-2h8c0 1.10457-.89543 2-2 2H0z"></path><path fill-rule="evenodd" clip-rule="evenodd" d="M6 0v8c0 1.10457-.89543 2-2 2V2c0-1.104569.89543-2 2-2z"></path></svg>
        </div>
    
    
    </div>
















</div>


</div>

 












    
    </div>




   


</div>






</div>


<div class="modal" id="crt_new_auta" tabindex="-1" role="dialog" aria-labelledby="..." style="display: none;" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-header" style="
    border-bottom: 0px;
">
        <h5 class="modal-title new-crt-head" id="exampleModalLongTitle" style="
    color: black;
    font-size: 15px;
">New Automation</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-x-circle" viewBox="0 0 16 16">
  <path d="M8 15A7 7 0 1 1 8 1a7 7 0 0 1 0 14zm0 1A8 8 0 1 0 8 0a8 8 0 0 0 0 16z"/>
  <path d="M4.646 4.646a.5.5 0 0 1 .708 0L8 7.293l2.646-2.647a.5.5 0 0 1 .708.708L8.707 8l2.647 2.646a.5.5 0 0 1-.708.708L8 8.707l-2.646 2.647a.5.5 0 0 1-.708-.708L7.293 8 4.646 5.354a.5.5 0 0 1 0-.708z"/>
</svg>
        </button>
      </div>
      <div class="modal-body">
    
    <input type="text" class="ip-by-def-dsg" id="auta-name-con-ip" placeholder="Enter Automation Name">
    
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary btn-blck-non-fcs" data-dismiss="modal">Close</button>
        <button type="button" class="btn btn-primary btn-blck-in-auta-fcs" id="create_new_auta">Create Automation</button>
      </div>
    </div>
  </div>
</div>



<div class="modal" id="giv-temp_auta_name" tabindex="-1" role="dialog" aria-labelledby="..." style="display: none; z-index: 1054; background: rgba(51, 48, 48, 0.52);" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-header" style="
    border-bottom: 0px;
">
        <h5 class="modal-title new-crt-head" id="exampleModalLongTitle" style="
    color: black;
    font-size: 15px;
">Template Name</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-x-circle" viewBox="0 0 16 16">
  <path d="M8 15A7 7 0 1 1 8 1a7 7 0 0 1 0 14zm0 1A8 8 0 1 0 8 0a8 8 0 0 0 0 16z"></path>
  <path d="M4.646 4.646a.5.5 0 0 1 .708 0L8 7.293l2.646-2.647a.5.5 0 0 1 .708.708L8.707 8l2.647 2.646a.5.5 0 0 1-.708.708L8 8.707l-2.646 2.647a.5.5 0 0 1-.708-.708L7.293 8 4.646 5.354a.5.5 0 0 1 0-.708z"></path>
</svg>
        </button>
      </div>
      <div class="modal-body">
    
    <input type="text" class="ip-by-def-dsg" id="auta_temp_name_def" placeholder="Enter Automation Name">
    
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary btn-blck-non-fcs" data-dismiss="modal">Close</button>
        <button type="button" class="btn btn-primary btn-blck-in-auta-fcs" id="send_temp_for_auta">Create Automation template</button>
      </div>
    </div>
  </div>
</div>





<div class="modal" id="add_temp_in_auta" tabindex="-1" role="dialog" aria-labelledby="..." style="display: none;" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content" style="height:60vh;">
      <div class="modal-header" style="
    border-bottom: 0px;
">
        <h5 class="modal-title new-crt-head" id="exampleModalLongTitle" style="
    color: black;
    font-size: 15px;
">Add For Automation</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-x-circle" viewBox="0 0 16 16">
  <path d="M8 15A7 7 0 1 1 8 1a7 7 0 0 1 0 14zm0 1A8 8 0 1 0 8 0a8 8 0 0 0 0 16z"/>
  <path d="M4.646 4.646a.5.5 0 0 1 .708 0L8 7.293l2.646-2.647a.5.5 0 0 1 .708.708L8.707 8l2.647 2.646a.5.5 0 0 1-.708.708L8 8.707l-2.646 2.647a.5.5 0 0 1-.708-.708L7.293 8 4.646 5.354a.5.5 0 0 1 0-.708z"/>
</svg>
        </button>
      </div>
      <div class="modal-body" id="app-of-temp-name-data">
    
    
    
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary btn-blck-non-fcs" data-dismiss="modal">Close</button>
        <button type="button" class="btn btn-primary btn-blck-in-auta-fcs"  >Create Automation</button>
      </div>
    </div>
  </div>
</div>



<div class="modal" id="rev_auta_crt" tabindex="-1" role="dialog" aria-labelledby="..." style="display: none;">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-header" style="
    border-bottom: 0px;
">
        <h5 class="modal-title new-crt-head" id="exampleModalLongTitle" style="
    color: black;
    font-size: 15px;
">Revoked Automation</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-x-circle" viewBox="0 0 16 16">
  <path d="M8 15A7 7 0 1 1 8 1a7 7 0 0 1 0 14zm0 1A8 8 0 1 0 8 0a8 8 0 0 0 0 16z"></path>
  <path d="M4.646 4.646a.5.5 0 0 1 .708 0L8 7.293l2.646-2.647a.5.5 0 0 1 .708.708L8.707 8l2.647 2.646a.5.5 0 0 1-.708.708L8 8.707l-2.646 2.647a.5.5 0 0 1-.708-.708L7.293 8 4.646 5.354a.5.5 0 0 1 0-.708z"></path>
</svg>
        </button>
      </div>
      <div class="modal-body">
    
    <input type="text" class="ip-by-def-dsg" id="rev_auta_name_chk" placeholder="Enter REVOKE And Click">
    
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary btn-blck-non-fcs" data-dismiss="modal">Close</button>
        <button type="button" class="btn btn-primary btn-blck-in-auta-fcs" id="rev_btn_auta">Revoke Automation</button>
      </div>
    </div>
  </div>
</div>










<div class="modal" id="del_auta_crt_mdl" tabindex="-1" role="dialog" aria-labelledby="..." style="display: none;">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-header" style="
    border-bottom: 0px;
">
        <h5 class="modal-title new-crt-head" id="exampleModalLongTitle" style="
    color: black;
    font-size: 15px;
">Delete Automation</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-x-circle" viewBox="0 0 16 16">
  <path d="M8 15A7 7 0 1 1 8 1a7 7 0 0 1 0 14zm0 1A8 8 0 1 0 8 0a8 8 0 0 0 0 16z"></path>
  <path d="M4.646 4.646a.5.5 0 0 1 .708 0L8 7.293l2.646-2.647a.5.5 0 0 1 .708.708L8.707 8l2.647 2.646a.5.5 0 0 1-.708.708L8 8.707l-2.646 2.647a.5.5 0 0 1-.708-.708L7.293 8 4.646 5.354a.5.5 0 0 1 0-.708z"></path>
</svg>
        </button>
      </div>
      <div class="modal-body">
    
    <input type="text" class="ip-by-def-dsg" id="del_auta_name_chk" placeholder="Enter DELETE And Click">
    
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary btn-blck-non-fcs" data-dismiss="modal">Close</button>
        <button type="button" class="btn btn-primary btn-blck-in-auta-fcs" id="del_btn_auta">Delete Automation</button>
      </div>
    </div>
  </div>
</div>



















<div class="modal" id="del_temp_mdl" tabindex="-1" role="dialog" aria-labelledby="..." style="display: none;">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-header" style="
    border-bottom: 0px;
">
        <h5 class="modal-title new-crt-head" id="exampleModalLongTitle" style="
    color: black;
    font-size: 15px;
">Delete Template</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-x-circle" viewBox="0 0 16 16">
  <path d="M8 15A7 7 0 1 1 8 1a7 7 0 0 1 0 14zm0 1A8 8 0 1 0 8 0a8 8 0 0 0 0 16z"></path>
  <path d="M4.646 4.646a.5.5 0 0 1 .708 0L8 7.293l2.646-2.647a.5.5 0 0 1 .708.708L8.707 8l2.647 2.646a.5.5 0 0 1-.708.708L8 8.707l-2.646 2.647a.5.5 0 0 1-.708-.708L7.293 8 4.646 5.354a.5.5 0 0 1 0-.708z"></path>
</svg>
        </button>
      </div>
      <div class="modal-body">
    
    <input type="text" class="ip-by-def-dsg" id="del_temp_chk" placeholder="Enter DELETE And Click">
    
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary btn-blck-non-fcs" data-dismiss="modal">Close</button>
        <button type="button" class="btn btn-primary btn-blck-in-auta-fcs" id="del_btn_auta">Delete Template</button>
      </div>
    </div>
  </div>
</div>




















<div class="modal" id="rnm_auta_crt_mdl" tabindex="-1" role="dialog" aria-labelledby="..." style="display: none;">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-header" style="
    border-bottom: 0px;
">
        <h5 class="modal-title new-crt-head" id="exampleModalLongTitle" style="
    color: black;
    font-size: 15px;
">Rename of <span id="rnm-auta-exs-nm"></span></h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-x-circle" viewBox="0 0 16 16">
  <path d="M8 15A7 7 0 1 1 8 1a7 7 0 0 1 0 14zm0 1A8 8 0 1 0 8 0a8 8 0 0 0 0 16z"></path>
  <path d="M4.646 4.646a.5.5 0 0 1 .708 0L8 7.293l2.646-2.647a.5.5 0 0 1 .708.708L8.707 8l2.647 2.646a.5.5 0 0 1-.708.708L8 8.707l-2.646 2.647a.5.5 0 0 1-.708-.708L7.293 8 4.646 5.354a.5.5 0 0 1 0-.708z"></path>
</svg>
        </button>
      </div>
      <div class="modal-body">
    
    <input type="text" class="ip-by-def-dsg" id="new-name-of-auta" placeholder="Enter New name">
    
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary btn-blck-non-fcs" data-dismiss="modal">Close</button>
        <button type="button" class="btn btn-primary btn-blck-in-auta-fcs" id="rnm_btn_auta">Rename Automation</button>
      </div>
    </div>
  </div>
</div>



<div class="modal" id="cp_auta_crt_mdl" tabindex="-1" role="dialog" aria-labelledby="..." style="display: none;">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-header" style="
    border-bottom: 0px;
">
        <h5 class="modal-title new-crt-head" id="exampleModalLongTitle" style="
    color: black;
    font-size: 15px;
">Duplicate <span id="cp-auta-exs-nm"></span></h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-x-circle" viewBox="0 0 16 16">
  <path d="M8 15A7 7 0 1 1 8 1a7 7 0 0 1 0 14zm0 1A8 8 0 1 0 8 0a8 8 0 0 0 0 16z"></path>
  <path d="M4.646 4.646a.5.5 0 0 1 .708 0L8 7.293l2.646-2.647a.5.5 0 0 1 .708.708L8.707 8l2.647 2.646a.5.5 0 0 1-.708.708L8 8.707l-2.646 2.647a.5.5 0 0 1-.708-.708L7.293 8 4.646 5.354a.5.5 0 0 1 0-.708z"></path>
</svg>
        </button>
      </div>
      <div class="modal-body">
    
    <input type="text" class="ip-by-def-dsg" id="cp-name-of-auta" placeholder="Enter New name">
    
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary btn-blck-non-fcs" data-dismiss="modal">Close</button>
        <button type="button" class="btn btn-primary btn-blck-in-auta-fcs" id="cp_btn_auta">Copy Automation</button>
      </div>
    </div>
  </div>
</div>




</body></html>






<script type="text/javascript">

id='<?php echo $id;?>';










auta_rev_start_name="";




$(document).on("click",".rev_btn_start_mdl",function(){


auta_rev_start_name=$(this).attr("data-targ-auta-id");


})



function rev_auta_in_db_fun(auta_name){


console.log(auta_name);

$.ajax({
                url : "./ajaxfile/rev_auta_in_db.php",
                type: "POST",
                data : {auta_name:auta_name}
        }).done(function(response){ 

if(response==1){

    location.reload();
}


        })


}



//copy automation

cp_auta_id="";


function cp_auta_name_in_db(old_name,new_name){




$.ajax({
                url : "./ajaxfile/copy_auta.php",
                type: "POST",
                data : {old_name:old_name,new_name:new_name}
        }).done(function(response){ 


if(response==1){

    location.reload();
}else{

err_msg_data("Please Enter Valid Name");


}


        })


}


$(document).on('click','.cp_trg_mdl_btn',function(){


cp_auta_id=$(this).attr('data-targ-auta-id');



$("#cp-auta-exs-nm").html(atob(cp_auta_id));



})


$(document).on('click','#cp_btn_auta',function(){



cp_auta_name_in_db(cp_auta_id,$("#cp-name-of-auta").val());


})












//rename javascript automation


rnm_auta_def="";


$(document).on('click','.rnm_trg_mdl_btn',function(){


rnm_auta_def=$(this).attr("data-targ-auta-id");

$("#rnm-auta-exs-nm").html(atob(rnm_auta_def));

})



function rename_auta_name_in_db(old_name,new_name){


console.log(new_name);

$.ajax({
                url : "./ajaxfile/rnm_data_in_db.php",
                type: "POST",
                data : {old_name:old_name,new_name:new_name}
        }).done(function(response){ 


if(response==1){

    location.reload();
}


        })


}

$(document).on('click','#rnm_btn_auta',function(){

nw_name_of_auta=$("#new-name-of-auta").val();



if(nw_name_of_auta.length>0){


rename_auta_name_in_db(rnm_auta_def,nw_name_of_auta);



}


})





//delete autaomation from db nd file

del_auta_id="";

$(document).on('click','.del_start_mdl_btn',function(){

del_auta_id=$(this).attr('data-targ-auta-id');





})





function del_auta_frm_fl(auta_name){



$.ajax({
                url : "./ajaxfile/del_auta_in_db.php",
                type: "POST",
                data : {auta_name:auta_name}
        }).done(function(response){ 

            console.log(response);

if(response==1){

    location.reload();
}


        })


}

$(document).on('click','#del_btn_auta',function(){


console.log($("#del_auta_name_chk").val());

if($("#del_auta_name_chk").val()=="DELETE"){




del_auta_frm_fl(del_auta_id);

}else{


err_msg_data("Enter DELETE As it is");

}


})





$(document).on('click','#rev_btn_auta',function(){




if($("#rev_auta_name_chk").val()=="REVOKE"){



rev_auta_in_db_fun(auta_rev_start_name);

}else{


    err_msg_data("Enter REVOKE As it is");
}


})




$(document).on('click',"#create_new_auta",function(){

auta_name=$("#auta-name-con-ip").val();

console.log(auta_name);

$.ajax({
                url : "./ajaxfile/crt_new_auta.php",
                type: "POST",
                data : {auta_name:auta_name}
        }).done(function(response){ 

if(response==1){



window.location="./create/?auta_id="+btoa(auta_name);

}else{


err_msg_data("Please Enter Valid Name");

}

        })


})


function init_auta_name_dis_str(data){

str_app='';

for(const val of data){


    if(val['status']=="0"){

str_of_act_dt='<div class="con-of-cnt-data">Launch Now</div>';
str_of_dp_con='<div class="dropdown-menu" aria-labelledby="dropdownMenuButton" x-placement="bottom-start" style="position: absolute; will-change: transform; top: 0px; left: 0px; transform: translate3d(32px, 32px, 0px);"> <a class="dropdown-item " href="./create/?auta_id='+btoa(val['auta_name'])+'">Edit</a> <a class="dropdown-item rnm_trg_mdl_btn" data-toggle="modal" data-target="#rnm_auta_crt_mdl" data-targ-auta-id="'+btoa(val['auta_name'])+'" href="#">Rename</a> <a class="dropdown-item cp_trg_mdl_btn" data-toggle="modal" data-target="#cp_auta_crt_mdl" href="#" data-targ-auta-id="'+btoa(val['auta_name'])+'">Duplicate</a><a class="dropdown-item del_start_mdl_btn" style="color:rgb(140, 3, 3);"  data-toggle="modal" data-target="#del_auta_crt_mdl" href="#" data-targ-auta-id="'+btoa(val['auta_name'])+'">Delete</a>  </div>';

    }else{


str_of_act_dt='<div class="con-of-cnt-data">'+val['cnt_res']+' reach</div>';
str_of_dp_con='<div class="dropdown-menu" aria-labelledby="dropdownMenuButton" x-placement="bottom-start" style="position: absolute; will-change: transform; top: 0px; left: 0px; transform: translate3d(32px, 32px, 0px);"> <a class="dropdown-item rev_btn_start_mdl" href="#" data-toggle="modal" data-target="#rev_auta_crt" data-targ-auta-id="'+btoa(val['auta_name'])+'">Revoke</a> <a class="dropdown-item " href="#">Reached</a>   </div>';
    }

str_app+='<div class="auta-dis-on-dash"> <div class="main-con-name"> <span class="bdg-tp-btn">Classic</span> <div class="def-name-con-crd">'+val['auta_name']+'</div> </div> <div class="def_stat-of-dt"> '+str_of_act_dt+' <div class="con-of-dp-data" style=""> <div class="dropdown" style=" height: 32px; "> <button class="btn btn-secondary dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> <img src="https://res.cloudinary.com/heptera/image/upload/v1621831794/dashboard/more_horiz_black_24dp_kiwldy.svg" class="img-of-act"> </button> '+str_of_dp_con+' </div> </div> </div> </div>';

}

$("#dyn_con_of_all_auta").append(str_app);


}

function init_auta_name_dis(){


$.ajax({
                url : "./ajaxfile/get_all_auta_name.php",
                type: "GET"
                
        }).done(function(response){ 

init_auta_name_dis_str(JSON.parse(response));

        })

}


function init_temp_data_in_mdl(data){

str_app='';


for(const val of data){

temp_name_dis=atob(val['name'].split("^")[1]);

date_dis=new Date(val['dateofcrt']).toUTCString();

str_app+='<div class="con-of-temp-lst add_in_auta_temp" data-temp-name="'+val['name']+'" data-toggle="modal" data-target="#giv-temp_auta_name"> <div class="name-of-temp-data"> <span class="temp-name">'+temp_name_dis+'</span><br> <span class="crt-data-of-tmp">'+date_dis+'</span> </div> <div class="edit-in-editor-btn"> <button type="button" class="btn btn-secondary btn-blck-non-fcs" data-dismiss="modal" style=" float: right; ">Open In Editor</button> </div> </div>';


}


$("#app-of-temp-name-data").html(str_app);

}


temp_auta_name="";

$(document).on('click',".add_in_auta_temp",function(){

temp_auta_name=$(this).attr('data-temp-name');







})


$(document).on('click',"#send_temp_for_auta",function(){


def_temp_name=$("#auta_temp_name_def").val();



$.ajax({
                url : "./ajaxfile/send_for_auta_temp.php",
                type: "POST",
                data : {temp_id:temp_auta_name,name_temp:def_temp_name}
        }).done(function(response){ 

if(response==1){

location.reload();

}else{

err_msg_data("Please Enter valid Name");

}

        })


})


function init_temp_in_dis_dash(data){

str_app='';


for(const val of data){


name_temp_def=atob(val['temp_id']);

str_app+='<div class="auta-dis-on-dash"> <div class="main-con-name"> <img class="img-temp-of-mark" src="https://scr.auftera.com/scr-api/?url=https://template.auftera.com/template/crt-template/crtedtemp/497889959^c210cF92ZXJpZmljYXRpb24=.html&amp;width=700&amp;height=800"> </div> <div class="def_stat-of-dt"> <div class="con-of-cnt-data">'+name_temp_def+'</div> <div class="con-of-dp-data" style=""> <div class="dropdown" style=" height: 32px; "> <button class="btn btn-secondary dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> <img src="https://res.cloudinary.com/heptera/image/upload/v1621831794/dashboard/more_horiz_black_24dp_kiwldy.svg" class="img-of-act"> </button> <div class="dropdown-menu" aria-labelledby="dropdownMenuButton" x-placement="bottom-start" style="position: absolute; will-change: transform; top: 0px; left: 0px; transform: translate3d(32px, 32px, 0px);"> <a class="dropdown-item com-for-lnk" data-for-serv="1" data-path-ses="template/" data-target-link="https://template.auftera.com/template/crt-template/" href="#">View </a> <a class="dropdown-item del-temp-mdl-trg" style="color:rgb(140, 3, 3)" data-toggle="modal" data-target="#del_temp_mdl" data-trg-temp-id="'+val['temp_id']+'"    href="#">Delete</a> </div> </div> </div> </div> </div>';

}



$("#all_con_of_temp_data").append(str_app);

}

temp_id_act="";

$(document).on('click','.del-temp-mdl-trg',function(){

temp_id_act=$(this).attr('data-trg-temp-id');

})


function del_temp_auta(temp_id){


$.ajax({
                url : "./ajaxfile/del_auta_temp.php",
                type: "POST",
                data : {temp_id:temp_id}
        }).done(function(response){ 

if(response==1){

location.reload();
}else{

    
}

        })



}


$(document).on('click','#del_btn_auta',function(){


if($("#del_temp_chk").val()=="DELETE"){


del_temp_auta(temp_id_act);

}else{
err_msg_data("Enter DELETE As it is");

}


})

function init_temp_data(){


$.ajax({
    url : './ajaxfile/get-all-temp.php',
    type: 'GET'
  }).done(function(response){

init_temp_in_dis_dash(JSON.parse(response));



  })


}

function init_temp_mdl_data_temp_serve(){


$.ajax({
    url : 'https://template.auftera.com/template/temp_res/gettempdata.php?id='+id,
    type: 'GET'
  }).done(function(response){

init_temp_data_in_mdl(JSON.parse(response));



  })

}




$(document).ready(function(){


$('[data-toggle="tooltip"]').tooltip();

init_auta_name_dis();

init_temp_data();
init_temp_mdl_data_temp_serve();

})








function err_msg_data(message){


$("#con-of-err-msg").html(message);

$("#err_msg_dt_trg").css('display','inline-block');



setTimeout(
    function() {


      $("#con-of-err-msg").empty();
$("#err_msg_dt_trg").css('display','none');
      
    }, 5000);


}


$(document).on('click','#cncl-err-msg',function(){


$("#con-of-err-msg").empty();
$("#err_msg_dt_trg").css('display','none');

})

</script>