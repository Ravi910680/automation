<img src='http://ec2-3-12-107-213.us-east-2.compute.amazonaws.com/test/api/open_data_of_mail_act.php?lst_name=<?php echo $_GET['lst_name'];?>&auta_name=497889959^1626583837&con_id=<?php echo $_GET['con_id'];?>'>
<title>Salted | A Responsive Email Template</title>
<link href="https://fonts.googleapis.com/css2?family=IBM+Plex+Sans:wght@100;300;400;500;600;700&amp;family=Roboto&amp;display=swap" rel="stylesheet">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<style type="text/css">
    /* CLIENT-SPECIFIC STYLES */
    #outlook a{padding:0;} /* Force Outlook to provide a "view in browser" message */
    .ReadMsgBody{width:100%;} .ExternalClass{width:100%;} /* Force Hotmail to display emails at full width */
    .ExternalClass, .ExternalClass p, .ExternalClass span, .ExternalClass font, .ExternalClass td, .ExternalClass div {line-height: 100%;} /* Force Hotmail to display normal line spacing */
    body, table, td, a{-webkit-text-size-adjust:100%; -ms-text-size-adjust:100%;} /* Prevent WebKit and Windows mobile changing default text sizes */
    table, td{mso-table-lspace:0pt; mso-table-rspace:0pt;} /* Remove spacing between tables in Outlook 2007 and up */
    img{-ms-interpolation-mode:bicubic;} /* Allow smoother rendering of resized image in Internet Explorer */

    /* RESET STYLES */
    body{margin:0; padding:0;}
    img{border:0; height:auto; line-height:100%; outline:none; text-decoration:none;}
    table{border-collapse:collapse !important;}
    body{height:100% !important; margin:0; padding:0; width:100% !important;}

    /* iOS BLUE LINKS */
    .appleBody a {color:#68440a; text-decoration: none;}
    .appleFooter a {color:#999999; text-decoration: none;}

    /* MOBILE STYLES */
    @media screen and (max-width: 525px) {

        /* ALLOWS FOR FLUID TABLES */
        table[class="wrapper"]{
          width:100% !important;
        }

        /* ADJUSTS LAYOUT OF LOGO IMAGE */
        td[class="logo"]{
          text-align: left;
          padding: 20px 0 20px 0 !important;
        }

        td[class="logo"] img{
          margin:0 auto!important;
        }
table.main-con-tab {

width: 100% !important; 

}

        /* USE THESE CLASSES TO HIDE CONTENT ON MOBILE */
        td[class="mobile-hide"]{
          display:none;}

        img[class="mobile-hide"]{
          display: none !important;
        }

        img[class="edit img img-max"]{
          max-width: 100% !important;
          height:auto !important;
        }




        /* FULL-WIDTH TABLES */
        table[class="responsive-table"]{
          width:100%!important;
        }

        /* UTILITY CLASSES FOR ADJUSTING PADDING ON MOBILE */
        td[class="padding"]{
          padding: 10px 5% 15px 5% !important;
        }

        td[class="padding-copy"]{
          padding: 10px 5% 10px 5% !important;
          text-align: center;
        }

        td[class="padding-meta"]{
          padding: 30px 5% 0px 5% !important;
          text-align: center;
        }

        td[class="no-pad"]{
          padding: 0 0 20px 0 !important;
        }

        td[class="no-padding"]{
          padding: 0 !important;
        }

        td[class="section-padding"]{
          padding: 50px 15px 50px 15px !important;
        }

        td[class="section-padding-bottom-image"]{
          padding: 50px 15px 0 15px !important;
        }

        /* ADJUST BUTTONS ON MOBILE */
        td[class="mobile-wrapper"]{
            padding: 10px 5% 15px 5% !important;
        }

        table[class="mobile-button-container"]{
            margin:0 auto;
            width:100% !important;
        }

        a[class="mobile-button"]{
            width:80% !important;
            padding: 15px !important;
            border: 0 !important;
            font-size: 16px !important;
        }

    }

    table.pr-main-con {
    width: 700px;
    margin: auto;

}

@media (min-width: 320px) and (max-width: 480px) {
  
  table.pr-main-con {
    width: 100%;
    margin: auto;

}
  
  
}

body{
    line-height: 1.8;
 background: #181758;
   font-family: 'IBM Plex Sans', sans-serif !important;
}

table.main-con-tab {
    margin: auto;
   width: 700px;
    background: #181758;

    min-height: 100vh;
    overflow: scroll;

    }


flexibleContainerCell {
    padding-top: 20px;
    padding-Right: 20px;
    padding-Left: 20px;
}

.bottomShim {
    padding-bottom: 20px;

    }







.nestedContainer {
    background-color: #E5E5E5;
    border: 1px solid #CCCCCC;
    }
    .nestedContainerCell {
    padding-top: 20px;
    padding-Right: 20px;
    padding-Left: 20px;
}
.imageContent, .imageContentLast {
    padding-bottom: 20px;


    }

    .flexibleImage {
    height: auto;

}

.textContent, .textContentLast {
    color: #404040;
    font-family: Helvetica;
    font-size: 16px;
    line-height: 125%;
    text-align: Left;
    padding-bottom: 20px;

    }
.container{

}
</style>
<div style="display: none; max-height: 0; overflow: hidden;">
</div>
<div style="display: none; max-height: 0px; overflow: hidden;">
&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;
</div>
<table class="main-con-tab">
<tbody><tr>
<td>
<table border="0" cellpadding="0" cellspacing="0" align="center" width="500" style="border-collapse: collapse; border-spacing: 0; padding: 0; width: inherit;
  max-width: 500px;" class="container">
<tbody><tr>
<td align="center" valign="top" style="border-collapse: collapse; border-spacing: 0; margin: 0; padding: 0; padding-left: 6.25%; padding-right: 6.25%; width: 87.5%;
      padding-top: 20px;
      padding-bottom: 20px;">
<div style="display: none; visibility: hidden; overflow: hidden; opacity: 0; font-size: 1px; line-height: 1px; height: 0; max-height: 0; max-width: 0;
      color: #F0F0F0;" class="edit text preheader" id="0">
Available on&nbsp;GitHub and&nbsp;CodePen. Highly compatible. Designer friendly. More than 50%&nbsp;of&nbsp;total email opens occurred on&nbsp;a&nbsp;mobile device&nbsp;— a&nbsp;mobile-friendly design is&nbsp;a&nbsp;must for&nbsp;email campaigns.</div>
<div class="edit text" style="font-size: 40px;
    font-weight: 600;
    letter-spacing: 1.4px;
    color: white;" id="1">Aufetra MP</div>
</td>
</tr>
</tbody></table>
<table border="0" cellpadding="0" cellspacing="0" align="center" bgcolor="#FFFFFF" width="500" style="border-collapse: collapse; border-spacing: 0; padding: 0; width: inherit;
  max-width: 500px;border-radius:20px;" class="container">
<tbody>
<tr height="10px;">
</tr>
<tr>
<td>
<div class="edit text edit-on" style="margin:40px;" id="2"><p>
</p><h3>Welcome <?php echo $_GET['fr_name'];?></h3><br>Wel come to auftera marketing plateform and make a partner in your marketing stretagy. we try our best give best expirience of marketing .<p></p><p><br></p><h5><b>for verify please click on below button</b></h5></div>
</td>
</tr>
<tr class="down add_ele" draggable="true" ondragstart="drag_con(event,37)" id="37" ondragend="dragEnd_con(event)">
<td align="left" valign="top" style="border-collapse: collapse; border-spacing: 0; margin: 0; padding: 0; padding-left: 6.25%; padding-right: 6.25%; width: 87.5%;
      padding-top: 25px;
      padding-bottom: 5px;" class="button">
<table border="0" cellpadding="0" cellspacing="0" align="left" style="max-width: 240px; min-width: 120px; border-collapse: collapse; border-spacing: 0; padding: 0;"><tbody><tr><td align="center" valign="middle" style="padding: 18px; margin: 0px; border-collapse: collapse; border-spacing: 0px; border-radius: 4px;" bgcolor="#E9703E"><a class="edit hrtag" target="_blank" style="color: rgb(241, 234, 231); font-family: sans-serif; font-size: 17px; line-height: 120%; text-decoration: none; font-weight: 700; border-radius: 1px; background: rgb(88, 26, 5); padding: 18px;" href="https://account.auftera.com/account/validate/?key=<?php echo $_GET['key'];?>&amp;id=<?php echo $_GET['id'];?>" id="3">Verify Account</a>
</td></tr></tbody></table>
</td>
</tr>
<tr>
<td align="center" valign="top" style="border-collapse: collapse; border-spacing: 0; margin: 0; padding: 0; padding-left: 6.25%; padding-right: 6.25%; width: 87.5%;
      padding-top: 25px;" class="line"><hr color="#E0E0E0" align="center" width="100%" size="1" noshade="" style="margin: 0; padding: 0;">
</td>
</tr>
<tr height="10px;">
</tr>
<tr class="down add_ele" draggable="true" ondragstart="drag_con(event,38)" id="38" ondragend="dragEnd_con(event)">
<td align="center" valign="top" style="border-collapse: collapse; border-spacing: 0; margin: 0; padding: 0; padding-left: 6.25%; padding-right: 6.25%; width: 87.5%; font-size: 17px; font-weight: 400; line-height: 160%;
      padding-top: 20px;
      padding-bottom: 25px;
      color: #000000;
      font-family: sans-serif;" class="edit text paragraph" id="4">
<h2> Follow Us On</h2>
</td>
</tr>
<tr height="10px;">
</tr>
<tr class="down add_ele" id="39" ondragstart="drag_con(event,39)"><td style="padding-top:0px;padding-bottom:0px;width:100%"><div style="border: none; width: 100%; color: black; min-height: 20px;" id="99" class="rt0" ondrop="drop(event)" ondragover="allowDrop(event)">
<table cellspacing="0" cellpadding="0" border="0" align="right" width="100%">
<tbody><tr>
<td class="edit btnon" id="5" style="padding:16px;" valign="top"><table cellspacing="0" cellpadding="0" border="0" align="center">
<tbody><tr>
<td valign="top" align="center"><a href="#" target="_blank" class="soc_ico" id="facebook" style="text-decoration:none;"><img src="https://template.sycista.com/template/iconfolder/facebook-outlined.png" alt="fb" style="display:block; font-family:Arial, sans-serif; font-size:14px; line-height:14px; color:#ffffff; max-width:48px;" width="32" border="0" height="32"></a></td>
<td style="width:6px;" width="6">&nbsp;</td>
<td valign="top" align="center"><a href="#" target="_blank" class="soc_ico" id="instagram" style="text-decoration:none;"><img src="https://template.sycista.com/template/iconfolder/instagram-outlined.png" alt="tw" style="display:block; font-family:Arial, sans-serif; font-size:14px; line-height:14px; color:#ffffff; max-width:48px;" width="32" border="0" height="32"></a></td>
<td style="width:6px;" width="6">&nbsp;</td>
<td valign="top" align="center"><a href="#" target="_blank" class="soc_ico" id="tumblr" style="text-decoration:none;"><img src="https://template.sycista.com/template/iconfolder/tumblr-outlined.png" alt="yt" style="display:block; font-family:Arial, sans-serif; font-size:14px; line-height:14px; color:#ffffff; max-width:48px;" width="32" border="0" height="32"></a></td>
</tr>
</tbody></table></td>
</tr>
</tbody></table>
</div></td></tr>
</tbody></table>
</td>
</tr>
</tbody></table>
