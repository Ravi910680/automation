<img src='http://ec2-3-12-107-213.us-east-2.compute.amazonaws.com/test/api/open_data_of_mail_act.php?lst_name=<?php echo $_GET['lst_name'];?>&auta_name=497889959^1626584021&con_id=<?php echo $_GET['con_id'];?>'>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Oxygen Reignite</title>
<style type="text/css">
    /* Take care of image borders and formatting, client hacks */
    img { max-width: 600px; outline: none; text-decoration: none; -ms-interpolation-mode: bicubic;}
    a img { border: none; }
    table { border-collapse: collapse !important;}
    #outlook a { padding:0; }
    .ReadMsgBody { width: 100%; }
    .ExternalClass { width: 100%; }
    .backgroundTable { margin: 0 auto; padding: 0; width: 100% !important; }
    table td { border-collapse: collapse; }
    .ExternalClass * { line-height: 115%; }
    .container-for-gmail-android { min-width: 600px; }


    /* General styling */
    * {
      font-family: Helvetica, Arial, sans-serif;
    }

    body {
      -webkit-font-smoothing: antialiased;
      -webkit-text-size-adjust: none;
      width: 100% !important;
      margin: 0 !important;
      height: 100%;
      color: #676767;
    }

    td {
      font-family: Helvetica, Arial, sans-serif;
      font-size: 14px;
      color: #777777;
      text-align: center;
      line-height: 21px;
    }

    a {
      color: #676767;
      text-decoration: none !important;
    }

    .pull-left {
      text-align: left;
    }

    .pull-right {
      text-align: right;
    }

    .header-lg,
    .header-md,
    .header-sm {
      font-size: 32px;
      font-weight: 700;
      line-height: normal;
      padding: 35px 0 0;
      color: #4d4d4d;
    }

    .header-md {
      font-size: 24px;
    }

    .header-sm {
      padding: 5px 0;
      font-size: 18px;
      line-height: 1.3;
    }

    .content-padding {
      padding: 20px 0 30px;
    }

    .mobile-header-padding-right {
      width: 290px;
      text-align: right;
      padding-left: 10px;
    }

    .mobile-header-padding-left {
      width: 290px;
      text-align: left;
      padding-left: 10px;
    }

    .free-text {
      width: 100% !important;
      padding: 10px 60px 0px;
    }

    .block-rounded {
      border-radius: 5px;
      border: 1px solid #e5e5e5;
      vertical-align: top;
    }

    .button {
      padding: 55px 0 0;
    }

    .info-block {
      padding: 0 20px;
      width: 260px;
    }

    .mini-block-container {
      padding: 30px 50px;
      width: 500px;
    }

    .mini-block {
      background-color: #ffffff;
      width: 498px;
      border: 1px solid #cccccc;
      border-radius: 5px;
      padding: 60px 75px;
    }

    .block-rounded {
      width: 260px;
    }

    .info-img {
      width: 258px;
      border-radius: 5px 5px 0 0;
    }

    .force-width-img {
      width: 480px;
      height: 1px !important;
    }

    .force-width-full {
      width: 600px;
      height: 1px !important;
    }

    .user-img img {
      width: 82px;
      border-radius: 5px;
      border: 1px solid #cccccc;
    }

    .user-img {
      width: 92px;
      text-align: left;
    }

    .user-msg {
      width: 236px;
      font-size: 14px;
      text-align: left;
      font-style: italic;
    }

    .code-block {
      padding: 10px 0;
      border: 1px solid #cccccc;
      color: #4d4d4d;
      font-weight: bold;
      font-size: 18px;
      text-align: center;
    }

    .force-width-gmail {
      min-width:600px;
      height: 0px !important;
      line-height: 1px !important;
      font-size: 1px !important;
    }

     .button-width {
      width: 228px;
    }

  </style>
<style type="text/css" media="screen">
    @import url(http://fonts.googleapis.com/css?family=Oxygen:400,700);
  </style>
<style type="text/css" media="screen">
    @media screen {
      /* Thanks Outlook 2013! */
      td {
        font-family: 'Oxygen', 'Helvetica Neue', 'Arial', 'sans-serif' !important;
      }
    }
  </style>
<style type="text/css" media="only screen and (max-width: 480px)">
    /* Mobile styles */
    @media only screen and (max-width: 480px) {

      table[class*="container-for-gmail-android"] {
        min-width: 290px !important;
        width: 100% !important;
      }

      table[class="w320"] {
        width: 320px !important;
      }

      img[class="force-width-gmail"] {
        display: none !important;
        width: 0 !important;
        height: 0 !important;
      }

      a[class="button-width"],
      a[class="button-mobile"] {
        width: 248px !important;
      }

      td[class*="mobile-header-padding-left"] {
        width: 160px !important;
        padding-left: 0 !important;
      }

      td[class*="mobile-header-padding-right"] {
        width: 160px !important;
        padding-right: 0 !important;
      }

      td[class="header-lg"] {
        font-size: 24px !important;
        padding-bottom: 5px !important;
      }

      td[class="header-md"] {
        font-size: 18px !important;
        padding-bottom: 5px !important;
      }

      td[class="content-padding"] {
        padding: 5px 0 30px !important;
      }

       td[class="button"] {
        padding: 15px 0 5px !important;
      }

      td[class*="free-text"] {
        padding: 10px 18px 30px !important;
      }

      img[class="force-width-img"],
      img[class="force-width-full"] {
        display: none !important;
      }

      td[class="info-block"] {
        display: block !important;
        width: 280px !important;
        padding-bottom: 40px !important;
      }

      td[class="info-img"],
      img[class="info-img"] {
        width: 278px !important;
      }

      td[class="mini-block-container"] {
        padding: 8px 20px !important;
        width: 280px !important;
      }

      td[class="mini-block"] {
        padding: 20px !important;
      }

      td[class="user-img"] {
        display: block !important;
        text-align: center !important;
        width: 100% !important;
        padding-bottom: 10px;
      }

      td[class="user-msg"] {
        display: block !important;
        padding-bottom: 20px !important;
      }
    }
  </style>
<table align="center" cellpadding="0" cellspacing="0" class="container-for-gmail-android" width="600px" style="background-color: #f7f7f7;">
<tbody><tr height="10px;">
</tr>
<tr class="down add_ele" draggable="true" ondragstart="drag_con(event,48)" id="48" ondragend="dragEnd_con(event)">
<td align="left" valign="top" width="100%" style="background:repeat-x url(http://s3.amazonaws.com/swu-filepicker/4E687TRe69Ld95IDWyEg_bg_top_02.jpg) #ffffff;">
<center>
<img src="https://s3.amazonaws.com/swu-filepicker/SBb2fQPrQ5ezxmqUTgCr_transparent.png" class="force-width-gmail">
<table cellspacing="0" cellpadding="0" width="100%" bgcolor="#ffffff" background="http://s3.amazonaws.com/swu-filepicker/4E687TRe69Ld95IDWyEg_bg_top_02.jpg" style="background-color:transparent">
<tbody><tr>
<td width="100%" height="80" valign="top" style="text-align: center; vertical-align:middle;">
<!--[if gte mso 9]>
            <v:rect xmlns:v="urn:schemas-microsoft-com:vml" fill="true" stroke="false" style="mso-width-percent:1000;height:80px; v-text-anchor:middle;">
              <v:fill type="tile" src="http://s3.amazonaws.com/swu-filepicker/4E687TRe69Ld95IDWyEg_bg_top_02.jpg" color="#ffffff" />
              <v:textbox inset="0,0,0,0">
            <![endif]-->
<center>
<table cellpadding="0" cellspacing="0" width="600" class="w320">
<tbody><tr>
<td class="pull-left mobile-header-padding-left" style="vertical-align: middle;">
<img class="edit img" width="137" height="47" src="https://img.auftera.com/images/497889959^dW5kZWZpbmU=^0.png?1622616259724" alt="logo" id="0">
</td>
<td class="edit btnon" id="1" style="padding: 0px 10px;" valign="top"><table cellspacing="0" cellpadding="0" border="0" align="right">
<tbody><tr>
<td valign="top" align="center"><a href="#" target="_blank" class="soc_ico" id="facebook" style="text-decoration:none;"><img src="https://template.sycista.com/template/iconfolder/facebook-flat.png" alt="fb" style="display:block; font-family:Arial, sans-serif; font-size:14px; line-height:14px; color:#ffffff; max-width:48px;" width="48" border="0" height="48"></a></td>
<td style="width:6px;" width="6">&nbsp;</td>
<td valign="top" align="center"><a href="#" target="_blank" class="soc_ico" id="instagram" style="text-decoration:none;"><img src="https://template.sycista.com/template/iconfolder/instagram-flat.png" alt="tw" style="display:block; font-family:Arial, sans-serif; font-size:14px; line-height:14px; color:#ffffff; max-width:48px;" width="48" border="0" height="48"></a></td>
<td style="width:6px;" width="6">&nbsp;</td>
<td valign="top" align="center"><a href="#" target="_blank" class="soc_ico" id="tumblr" style="text-decoration:none;"><img src="https://template.sycista.com/template/iconfolder/tumblr-flat.png" alt="yt" style="display:block; font-family:Arial, sans-serif; font-size:14px; line-height:14px; color:#ffffff; max-width:48px;" width="48" border="0" height="48"></a></td>
</tr>
</tbody></table></td>
</tr>
</tbody></table>
</center>
<!--[if gte mso 9]>
              </v:textbox>
            </v:rect>
            <![endif]-->
</td>
</tr>
</tbody></table>
</center>
</td>
</tr>
<tr height="10px;">
</tr>
<tr class="down add_ele" draggable="true" ondragstart="drag_con(event,49)" id="49" ondragend="dragEnd_con(event)">
<td align="center" valign="top" width="100%" style="background-color: #f7f7f7;" class="content-padding">
<center>
<table cellspacing="0" cellpadding="0" width="600" class="w320">
<tbody><tr>
<td class="edit text header-lg" id="2">SMTP Server Verification</td>
</tr>
<tr>
<td class="edit text free-text" id="3">
We noticed you haven't been around for awhile and we wanted to say that we miss you. We've been working really hard to improve our services and selection and hope you will give us another visit.
</td>
</tr>
<tr>
<td class="mini-block-container">
<table cellspacing="0" cellpadding="0" width="100%" style="border-collapse:separate !important;">
<tbody><tr>
<td class="mini-block">
<table cellpadding="0" cellspacing="0" width="100%">
<tbody><tr>
<td class="edit text" style="padding-bottom: 30px;" id="4"></td>
</tr>
<tr>
<td class="edit text code-block" id="5"><?php echo $_GET['smtp_id'];?></td>
</tr>
<tr>
<td class="button">
<div><!--[if mso]>
                            <v:roundrect xmlns:v="urn:schemas-microsoft-com:vml" xmlns:w="urn:schemas-microsoft-com<?php echo $_GET['office'];?>word" href="http://" style="height:45px;v-text-anchor:middle;width:155px;" arcsize="15%" strokecolor="#ffffff" fillcolor="#ff6f6f">
                              <w:anchorlock/>
                              <center style="color:#ffffff;font-family:Helvetica, Arial, sans-serif;font-size:14px;font-weight:regular;">Shop Now</center>
                            </v:roundrect>
                          <![endif]--><a class="edit hrtag button-mobile" href="http://" style="background-color:#ff6f6f;border-radius:5px;color:#ffffff;display:inline-block;font-family:'Cabin', Helvetica, Arial, sans-serif;font-size:14px;font-weight:regular;line-height:45px;text-align:center;text-decoration:none;width:155px;-webkit-text-size-adjust:none;mso-hide:all;" id="6">Shop Now</a></div>
</td>
</tr>
</tbody></table>
</td>
</tr>
</tbody></table>
</td>
</tr>
</tbody></table>
</center>
</td>
</tr>
<tr><td align="center" valign="top" width="100%" style="background-color: #ffffff;  border-top: 1px solid #e5e5e5; border-bottom: 1px solid #e5e5e5;">
<center>
<table cellpadding="0" cellspacing="0" width="600" class="w320">
<tbody><tr>
<td class="content-padding">
<table cellpadding="0" cellspacing="0" width="100%">
<tbody><tr>
<td class="edit text header-md" id="7">
Our newest offers!
</td>
</tr>
</tbody></table>
</td>
</tr>
<tr>
<td style="padding-bottom: 75px;">
<table cellpadding="0" cellspacing="0" width="100%" style="border-collapse:separate !important;">
<tbody><tr>
<td class="info-block">
<table cellpadding="0" cellspacing="0" width="100%" style="border-collapse:separate !important;">
<tbody><tr>
<td class="block-rounded">
<table cellpadding="0" cellspacing="0" width="100%">
<tbody><tr>
<td class="info-img">
<img class="edit text info-img" src="https://res.cloudinary.com/heptera/image/upload/v1605712699/editor/c-d-x-PDX_a_82obo-unsplash_rmdy4k.jpg" alt="img" id="8">
</td>
</tr>
<tr>
<td style="padding: 15px;">
<table cellspacing="0" cellpadding="0" width="100%">
<tbody><tr>
<td class="edit text" style="text-align:left; width:155px" id="9">
<a href=""><span class="header-sm">Pink Shoes</span></a><br>
The hottest summer sneakers are in now!
</td>
<td class="edit text" style="text-align:right; vertical-align: top;" id="10">
<strong>$29.99</strong>
</td>
</tr>
</tbody></table>
</td>
</tr>
<tr>
<td style="padding: 15px;">
<div><!--[if mso]>
                                <v:roundrect xmlns:v="urn:schemas-microsoft-com:vml" xmlns:w="urn:schemas-microsoft-com<?php echo $_GET['office'];?>word" href="http://" style="height:45px;v-text-anchor:middle;width:228px;" arcsize="15%" strokecolor="#ffffff" fillcolor="#ff6f6f">
                                  <w:anchorlock/>
                                  <center style="color:#ffffff;font-family:Helvetica, Arial, sans-serif;font-size:14px;font-weight:regular;">My Account</center>
                                </v:roundrect>
                              <![endif]--><a class="edit hrtag button-width" href="http://" style="background-color:#ff6f6f;border-radius:5px;color:#ffffff;display:inline-block;font-family:'Cabin', Helvetica, Arial, sans-serif;font-size:14px;font-weight:regular;line-height:45px;text-align:center;text-decoration:none;-webkit-text-size-adjust:none;mso-hide:all;" id="11">View Now!</a></div>
</td>
</tr>
</tbody></table>
</td>
</tr>
</tbody></table>
</td>
<td class="info-block">
<table cellpadding="0" cellspacing="0" width="100%" style="border-collapse:separate !important;">
<tbody><tr>
<td class="block-rounded">
<table cellpadding="0" cellspacing="0" width="100%">
<tbody><tr>
<td class="info-img">
<img width="258" height="210" class="edit img info-img edit-on" src="https://img.auftera.com/images/497889959^dW5kZWZpbmU=^0.png?1622616304796" alt="img" id="12">
</td>
</tr>
<tr>
<td style="padding: 15px;">
<table cellspacing="0" cellpadding="0" width="100%">
<tbody><tr>
<td class="edit text" style="text-align:left; width:155px" id="13">
<a href=""><span class="header-sm">Golden Earings</span></a><br>
New city looks!
<br>
&nbsp;
</td>
<td class="edit text" style="text-align:right; vertical-align: top;" id="14">
<strong>$29.99</strong>
</td>
</tr>
</tbody></table>
</td>
</tr>
<tr>
<td style="padding: 15px;">
<div><!--[if mso]>
                                <v:roundrect xmlns:v="urn:schemas-microsoft-com:vml" xmlns:w="urn:schemas-microsoft-com<?php echo $_GET['office'];?>word" href="http://" style="height:45px;v-text-anchor:middle;width: 228px;" arcsize="15%" strokecolor="#ffffff" fillcolor="#ff6f6f">
                                  <w:anchorlock/>
                                  <center style="color:#ffffff;font-family:Helvetica, Arial, sans-serif;font-size:14px;font-weight:regular;">My Account</center>
                                </v:roundrect>
                              <![endif]--><a class="edit hrtag button-width" href="http://" style="background-color:#ff6f6f;border-radius:5px;color:#ffffff;display:inline-block;font-family:'Cabin', Helvetica, Arial, sans-serif;font-size:14px;font-weight:regular;line-height:45px;text-align:center;text-decoration:none; -webkit-text-size-adjust:none;mso-hide:all;" id="15">View Now!</a></div>
</td>
</tr>
</tbody></table>
</td>
</tr>
</tbody></table>
</td>
</tr>
</tbody></table>
</td>
</tr>
</tbody></table>
</center>
</td>
</tr><tr height="10px;">
</tr>
<tr class="down add_ele" draggable="true" ondragstart="drag_con(event,50)" id="50" ondragend="dragEnd_con(event)">
<td align="center" valign="top" width="100%" style="background-color: #f7f7f7; height: 100px;">
<center>
<table cellspacing="0" cellpadding="0" width="600" class="w320">
<tbody><tr>
<td class="edit text" style="padding: 25px 0 25px" id="16">
<strong>Awesome Inc</strong><br>
1234 Awesome St <br>
Wonderland <br><br>
</td>
</tr>
</tbody></table>
</center>
</td>
</tr>
</tbody></table>
