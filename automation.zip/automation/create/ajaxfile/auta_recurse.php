<?php

require("../confige/auta_conf.php");
require("./auta_perform.php");

function select_query($conn,$sel_query){


	$ret_arr=array();

$result = $conn->query($sel_query);

if ($result->num_rows > 0) {
  // output data of each row
  while($row = $result->fetch_assoc()) {
    

    array_push($ret_arr,$row);
  }
}

return $ret_arr;

}


function isrt_query_db($conn,$isrt_query){


if($conn->query($isrt_query)){

return 1;

}else{
	return $conn->error;
}


}

function make_query($data){
$str_app="";
	foreach ($data as $key => $value) {
		$str_app.=$key."='".$value."' and ";
	}

	return substr_replace($str_app ,"", -4);
}




function add_new_act_in_tbl($arr_isrt,$conn,$con_id){



foreach ($arr_isrt as $key => $value) {
	



	$usr_id=$value['usr_id'];
	$auta_name=$value['auta_name'];
	$act_id=$value['blck_id'];
	$act_date=gmdate("Y-m-d\TH:i:s\Z");
	$flg_suc=0;

$isrt_query_of_act="insert into auta_flow (usr_id,auta_name,act_id,con_id,act_date,flg_suc) values('$usr_id','$auta_name','$act_id','$con_id','$act_date','$flg_suc')";



isrt_query_db($conn,$isrt_query_of_act);


}

}







function sel_auta_act_in_db_isrt($conn,$data_arr,$con_id){










$sel_query="select * from auta_act where ".make_query($data_arr);


$sel_act_perf_2=select_query($conn,$sel_query);



foreach ($sel_act_perf_2 as $key => $value) {

$sel_act_perf=$value;



	if(perform_act_of_auta($conn,$sel_act_perf,$con_id) && $sel_act_perf['act_nxt']!=""){



$data_arr['blck_id']=$sel_act_perf['act_nxt'];
$sel_query="select * from auta_act where ".make_query($data_arr);

$sel_nxt_act_data=select_query($conn,$sel_query);




add_new_act_in_tbl($sel_nxt_act_data,$conn,$con_id);

}


	
}










}




function sel_latest_act($conn){

$data_arr=array();

$utc_tm=gmdate("Y-m-d H:i:s");

$sel_query="select usr_id,auta_name,con_id,act_id,min(act_date) from auta_flow where flg_suc='0' and act_date<'".$utc_tm."' LIMIT 1";

$data_trg_act=select_query($conn,$sel_query)[0];

$data_arr['usr_id']=$data_trg_act['usr_id'];
$data_arr['auta_name']=$data_trg_act['auta_name'];
$data_arr['blck_id']=$data_trg_act['act_id'];


sel_auta_act_in_db_isrt($conn,$data_arr,$data_trg_act['con_id']);

unset($data_arr['blck_id']);
$data_arr['act_id']=$data_trg_act['act_id'];
$data_arr['con_id']=$data_trg_act['con_id'];


#update_tag_suc_in_flw($conn,$data_arr);

}

sel_latest_act($auta_conn);


?>