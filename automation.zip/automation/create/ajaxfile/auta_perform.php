<?php

function httpGet($url)
{
    $ch = curl_init();  
 
    curl_setopt($ch,CURLOPT_URL,$url);
    curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
//  curl_setopt($ch,CURLOPT_HEADER, false); 
 
    $output=curl_exec($ch);
 
    curl_close($ch);
    return $output;
}
 



function get_contact_det($lst_name,$con_id){


require("../confige/contact_conf.php");


$select_query="select * from `$lst_name` where con_id='$con_id'";

return select_query($conn_contact,$select_query)[0];

}


function httpPost($url,$params)
{
  $postData = '';
   //create name value pairs seperated by &
   foreach($params as $k => $v) 
   { 
      $postData .= $k . '='.$v.'&'; 
   }
   $postData = rtrim($postData, '&');
 
    $ch = curl_init();  
 
    curl_setopt($ch,CURLOPT_URL,$url);
    curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
    curl_setopt($ch,CURLOPT_HEADER, false); 
    curl_setopt($ch, CURLOPT_POST, count($params));
        curl_setopt($ch, CURLOPT_POSTFIELDS, $postData);    
 
    $output=curl_exec($ch);
 
    curl_close($ch);
    return $output;
 
}




function change_tag_data_con($data_arr,$con_id){







$main_act=$data_arr['cmp'];
$data_main=$data_arr['data'];

$lst_name=$data_arr['field'];



$get_contact_det=get_contact_det($lst_name,$con_id);



if($main_act=="add_tg"){
$tag_up_str=$get_contact_det['tag'].$data_main.",";
}else{


$tag_up_str=str_replace($data_main.",","",$get_contact_det['tag']);

}




$req_jsn_arr=array($get_contact_det['email']=>$tag_up_str);

$jsn_str=json_encode($req_jsn_arr);

$req_arr['listname']=$lst_name;
$req_arr['requestoflist']=$jsn_str;
$req_arr['get_stat_act']="tag";



$req_url="https://contact.auftera.com/contact/mngc/ajaxfile/update_tag.php";

echo httpPost($req_url,$req_arr);

}




function create_contact_arch($data_arr,$con_id){



$lst_name=$data_arr['field'];
$data_main=$data_arr['data'];

$str_up=0;
if($data_main=="arch"){

	$str_up=1;
}


$get_contact_det=get_contact_det($lst_name,$con_id);



$req_jsn_arr=array($get_contact_det['email']=>$str_up);

$jsn_str=json_encode($req_jsn_arr);

$req_arr['listname']=$lst_name;
$req_arr['requestoflist']=$jsn_str;
$req_arr['get_stat_act']="arch";

$req_url="https://contact.auftera.com/contact/mngc/ajaxfile/update_tag.php";

echo httpPost($req_url,$req_arr);


}




function check_cond_of_auta($data_arr,$con_id){


$lst_name=$data_arr['field'];
$data_main=$data_arr['data'];
$cmp_data=$data_arr['cmp'];

$splt_lst_name=explode("#", $lst_name);
$lst_name=$splt_lst_name[0];
$perf_name=$splt_lst_name[1];


if($perf_name=="segment"){


}else{

$sel_query="select * from `$lst_name` where ".$perf_name." ".$cmp_data." '".$data_main."' and con_id='".$con_id."' and arch='0'";

}




require("../confige/contact_conf.php");



if(count(select_query($conn_contact,$sel_query))==1){



return true;
}else{
	return false;
}





}


function change_sub_stat_con($data_arr,$con_id){




$lst_name=$data_arr['field'];
$data_main=$data_arr['data'];



$get_contact_det=get_contact_det($lst_name,$con_id);



$req_jsn_arr=array($get_contact_det['email']=>$data_main);

$jsn_str=json_encode($req_jsn_arr);

$req_arr['listname']=$lst_name;
$req_arr['requestoflist']=$jsn_str;
$req_arr['get_stat_act']="substatus";

$req_url="https://contact.auftera.com/contact/mngc/ajaxfile/update_tag.php";

echo httpPost($req_url,$req_arr);

}



function update_tag_suc_in_flw($conn,$data){


$update_query="update auta_flow set flg_suc='1' where ".make_query($data);

echo $update_query;

isrt_query_db($conn,$update_query);


}






function per_delay_tm_task($conn,$value,$con_id){




$current_date=gmdate("Y-m-d\TH:i:s\Z");



$next_tm="+".$value['cmp']." ".$value['data'];



$usr_id=$value['usr_id'];
	$auta_name=$value['auta_name'];
	$act_id=$value['act_nxt'];
	$act_date=gmdate("Y-m-d\TH:i:s\Z",strtotime($next_tm, strtotime($current_date)));
	$flg_suc=0;


$isrt_query_of_act="insert into auta_flow (usr_id,auta_name,act_id,con_id,act_date,flg_suc) values('$usr_id','$auta_name','$act_id','$con_id','$act_date','$flg_suc')";

isrt_query_db($conn,$isrt_query_of_act);

return false;

}


function perform_act_of_auta($conn,$data_arr,$con_id){

$tp_of_perform=$data_arr['act_tp'];

$con_id=1;






if($tp_of_perform=="chg_tg_act"){

	
change_tag_data_con($data_arr,$con_id);


}else if($tp_of_perform=="crt_arch_act"){



	create_contact_arch($data_arr,$con_id);
}else if($tp_of_perform=="chg_stat_act"){

	change_sub_stat_con($data_arr,$con_id);
}else if($tp_of_perform=="tm_delay_act"){


return per_delay_tm_task($conn,$data_arr,$con_id);

}else if($tp_of_perform=="chk_cond_act"){


return check_cond_of_auta($data_arr,$con_id);

}



return false;

}

?>