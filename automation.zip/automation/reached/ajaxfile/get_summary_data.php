<?php

session_start();


require("../../create/confige/auta_conf.php");


function select_query($conn,$sel_query){


	$ret_arr=array();

$result = $conn->query($sel_query);

if ($result->num_rows > 0) {
  // output data of each row
  while($row = $result->fetch_assoc()) {
    

    array_push($ret_arr,$row);
  }
}

return $ret_arr;

}


function sel_auta_trg_in_db_isrt($conn,$usr_id,$auta_id){

$sel_query="select * from auta_trg where usr_id='$usr_id' and auta_name='$auta_id'";



return select_query($conn,$sel_query)[0];






}


function get_data_of_start_auta($conn,$auta_id,$usr_id,$lst_id){


$servername = "database-1.ckv23lvefwmm.us-east-2.rds.amazonaws.com";
$username = "admin";
$password = "Ravi91068";
$dbname = "list_contacts";

$conn3 = mysqli_connect($servername, $username, $password,$dbname);







$query="select con_id ,count(con_id),act_date from auta_flow where usr_id='$usr_id' and auta_name='$auta_id' and act_id LIKE '0#%' group by con_id";





$get_all_res_arr=select_query($conn,$query);

$res_arr=array("data"=>array());


foreach ($get_all_res_arr as $key => $value) {

	$loc_arr=array();
	
$con_id=$value['con_id'];



$query="select email,con_id from `$lst_id` where con_id='$con_id'";

$email=select_query($conn3,$query)[0]['email'];

$loc_arr['con_id']=$con_id;
$loc_arr['res_cnt']=$value['count(con_id)'];
$loc_arr['email']=$email;
$loc_arr['act_date']=$value['act_date'];


array_push($res_arr['data'], $loc_arr);
	 
}



return $res_arr;

 


}


$id=$_SESSION['id'];
$auta_id=$_GET['auta_id'];

$get_trg_data=sel_auta_trg_in_db_isrt($auta_conn,$id,$auta_id);



$ret_arr=get_data_of_start_auta($auta_conn,$auta_id,$id,$get_trg_data['data']);

$ret_arr['trigger']=$get_trg_data;


echo json_encode($ret_arr);


?>