
<?php
session_start();



$id=$_SESSION['id'];

?>






<html><head>


<link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=Lato:ital,wght@0,100;0,300;0,400;0,700;0,900;1,100;1,300;1,400;1,700;1,900&display=swap" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
<link href="https://res.cloudinary.com/dbkkxj00u/raw/upload/v1601356785/font-owsome/all_epmuwn.css" rel="stylesheet">

<link rel="stylesheet" type="text/css" href="../load.css">
<style type="text/css">


.sd-con-ico.dsc-inln-flx {
    width: 8%;
    height: 100%;
}

.main-con-of-crm.dsc-inln-flx {
    width: 92%;
    height: 100%;
    float: right;
    background: #fafafa;
    overflow: scroll;
}

    .dsc-inln-flx {
    display: inline-block;
}

.sd-hd-con {
    height: 10vh;
    text-align: center;
    }

    .icon-con-of-sd {
    height: 90vh;
    width: 100%;
}

.icon-main-con {
    height: auto;
    width: 100%;
    position: relative;
    top: 50%;
    -ms-transform: translateY(-50%);
    transform: translateY(-50%);
    }

    .con-ico {
    padding: 20px;
    text-align: center;
}

img.con-of-ico-img {
    height: 30px;
    }




.con-of-main-splt {
    width: 20%;
    height: 100vh;
    display: inline-block;

}
.sd-hd-con {
    height: 10vh;
    text-align: center;
    }

   
h2.head-od-dt-shw {
    margin: 0px;
    }


button.btn-of-drk-back {
    height: 6vh;
    width: 100%;
    background: #125ef6;
    border: 0px;
    border-radius: 5px;
    color: white;
}

.con-of-dt-sel-ele {
    height: 80vh;
    width: 100%;
    overflow: scroll;
    }

    .container-2GnNH {
    display: -webkit-box;
    display: -ms-flexbox;
    display: flex;
    -webkit-box-orient: horizontal;
    -webkit-box-direction: normal;
    -ms-flex-direction: row;
    flex-direction: row;
    -webkit-box-align: center;
    -ms-flex-align: center;
    align-items: center;
    padding: 15px;
}
a.com-for-lnk {
    text-decoration: none;
    color: black;
    }

    h2.head-od-dt-shw {
    margin: 0px;
    font-family: lato;
    font-size: 15px;
    font-weight: bolder;
}
.con-of-main-splt {
    width: 20%;
    height: 100vh;
    background: #e5eafc30;
    }


    .eml-add-main-con {
    width: 29%;
    height: 100vh;
    display: inline-block;
    vertical-align: top;
    margin: 0;
    padding: 0;
    font-size: 16px;
    
}

.sd-hd-con {
    height: 10vh;
    text-align: center;
    }
    input.srch-ip-fld {
    width: 100%;
    height: 3vh;
    border: none;
    font-family: 'Lato';
    font-weight: 500;
    color: #c7ccd7;
}
.con-of-full-email-dt {
    width: 100%;
    height: 90vh;
    }

    .img-eml-ico-con {
    font-family: 'Lato';
    padding: 15px;
    border-radius: 50%;
    background: pink;
    margin-right: 10px;
    color: #ca1938;
}
.sub-ln-of-email-txt {
    width: 240px;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
    font-family: 'Lato';
    color: #908c8c;
    font-size: 13px;
}
input.srch-ip-fld:focus{
    outline: none;
    border: none;
}

    .fnt-ico-sel {
    width: 20px;
    text-align: center;
}

.con-of-cht-usr {
    width: 50%;
    display: inline-block;
    height: 100vh;
    display: inline-block;
    vertical-align: top;
    margin: 0;
    padding: 0;
    border-left: 1px solid #f2f2f2;
    }





.con-ico:hover{
    cursor: pointer;
}

.head-of-dash{
    background: #4a154b;
    text-align: right;
    border-bottom-left-radius: 50px;
}


.dropdown-menu .dropdown-item {
    padding: .5rem 1rem;
    font-size: 13px;
    font-weight: 600;
}

button.dropdown-item.comm_up_btn:hover {
    background: #0d66d6;
    color: white;
    }

    .dropdown-header {
    padding: .5rem 1rem;
    color: #f6f9fc;
    font-size: .625rem;
    text-transform: uppercase;
    font-weight: 700;
}
.dropdown-header {
    display: block;
    padding: .5rem 1rem;
    margin-bottom: 0;
    font-size: 0.875rem;
    color: #8898aa;
    white-space: nowrap;
    }
    .dropdown-menu {
    padding: 10px !important;
    box-shadow: rgb(50 50 93 / 25%) 0px 2px 5px -1px, rgb(0 0 0 / 30%) 0px 1px 3px -1px !important;
}

.dropdown-item {
    border-radius: 10px;
    }

h6, .h6 {
    font-size: 0.625rem !important;
}


.head-of-inn-con {
    padding: 24px;
}
.all-auta-con {
    padding: 0px 24px;
    }
    span.nm-auta-con {
    font-size: 16px;
    font-weight: 500;
    font-family: 'lato';
    color: #00000080;
}

.crt-new-auta-con {
    width: 200px;
    background: rgb(4, 135, 175);
    padding: 24px 16px;
    border-radius: 10px;
    height: 250px;
    margin-right: 30px;
    margin-top: 20px;
}

    .new-crt-head {
    line-height: 28px;
    font-weight: 700;
    color: white;
    font-family: 'Lato';
}
.con-of-crt-new-img {
    text-align: center;
    width: min-content;
    margin-top: 60px;
    padding: 10px;
    margin-left: auto;
    margin-right: auto;
    border-radius: 50%;
    box-shadow: rgb(0 0 0 / 8%) 0px 2px 4px, rgb(0 0 0 / 6%) 0px 2px 12px, rgb(0 0 0 / 4%) 0px 8px 14px, rgb(0 0 0 / 2%) 0px 12px 16px;
    }

    .crt-new-auta-con:hover{
cursor: pointer;
    }

    .auta-dis-on-dash {
    width: 200px;
    padding: 24px 16px;
    border-radius: 10px;
    background: white;
    margin-right: 30px;
    height: 250px;
    padding-bottom: 0px;
    box-shadow: rgb(0 0 0 / 8%) 0px 2px 4px, rgb(0 0 0 / 6%) 0px 2px 12px;
    transition: .3s;
    margin-top: 20px;
}

.auta-dis-on-dash:hover{
    box-shadow: rgb(0 0 0 / 8%) 0px 2px 4px, rgb(0 0 0 / 6%) 0px 2px 12px, rgb(0 0 0 / 4%) 0px 8px 14px, rgb(0 0 0 / 2%) 0px 12px 16px;
cursor: pointer;

}
.main-con-name {
    flex: auto;
    min-height: 166px;
    display: inline-grid;
    width: 100%;
    }
    
    span.bdg-tp-btn {
    margin-left: auto;
    font-size: 12px;
    background: rgb(245, 249, 248);
    padding: 2px 10px;
    border-radius: 10px;
    color: rgb(2, 80, 65);
    font-family: 'Lato';
    font-weight: 600;
    letter-spacing: .4px;
    height: fit-content;
}
.def-name-con-crd {
    justify-content: center;
    flex-direction: column;
    display: flex;
    margin: auto;
    font-family: 'Lato';
    }
    .def_stat-of-dt {
    padding: 16px 0px;
    display: inline-flex;
    width: 100%;
    height: 60px;
}
.def_stat-of-dt > div {
    font-size: 14px;
    height: fit-content;
    
}
    .con-of-cnt-data {
    padding: 5.5px 10px;
    background: rgba(0, 0, 0, 0.07);
    border-radius: 5px;
    color: rgb(38, 38, 39);
    width: 60%;
    text-align: center;
    text-overflow: ellipsis;
    overflow: hidden;
    white-space: nowrap;
}
.def_stat-of-dt > div {
    font-size: 14px;
    height: fit-content;
    }

    .con-of-dp-data {
    width: 40%;
}

button#dropdownMenuButton {
    background: no-repeat;
    border: none;
    height: 32px;
    padding: 5.5px;
    float: right;
    }

.all-auta-con {
    padding: 0px 24px;
    display: inline-flex;

}
.dropdown-toggle::after{
    display: none;
}

.dropdown-menu.show{
    border: none;
    border-radius: 10px;
}

a.com-for-lnk {
    text-decoration: none;
    color: #00000091;
    }
    .marg-for-temp{
        margin-left: 0px;
        margin-right: 30px;
    }
    .img-temp-of-mark{
        width: 168px;
        height: 166px;
    }










  .ip-by-def-dsg {
    width: 100%;
    background-color: #FFFFFF;
    height: 48px;
    padding-left: 16px;
    padding-right: 16px;
    border-radius: 4px;
    margin: 8px 0px;
    border: 1px solid #B8B8B8;
    font-weight: 400;
    font-size: 14px;
    text-align: left;
    box-sizing: border-box;
    -webkit-transition-property: border-width,border-color,box-shadow;
    transition-property: border-width,border-color,box-shadow;
    -webkit-transition-duration: 0.1s;
    transition-duration: 0.1s;
    -webkit-transition-timing-function: ease-in;
    transition-timing-function: ease-in;
    box-shadow: 2px 2px 0 2px transparent;
    text-overflow: ellipsis;
    overflow: hidden;


  }

  .ip-by-def-dsg:focus {
    background-color: #fff;
    outline: 0;
    border-color: #524d52;
    box-shadow: 0 0 0 3px #bdb2bd4d;

    -webkit-transition-property: border-width,border-color,box-shadow;
    transition-property: border-width,border-color,box-shadow;
    -webkit-transition-duration: 0.1s;
    transition-duration: 0.1s;
    -webkit-transition-timing-function: ease-in;
    transition-timing-function: ease-in;

  }



button:disabled,
button[disabled]{
  border: 1px solid #999999;
  background-color: #cccccc;
  color: #666666;
  border: none;
  cursor: not-allowed;
}

.btn-blck-in-auta-fcs{
    display: inline-flex;
    -webkit-box-align: center;
    align-items: center;
    -webkit-box-pack: center;
    justify-content: center;
    background-color: rgb(38, 38, 39);
    color: rgb(255, 255, 255);
    position: relative;
    outline: none;
    font-family: inherit;
    border: 0px;
    transition: all 0.4s ease 0s;
    cursor: pointer;
    white-space: nowrap;
    text-decoration: none;
    border-radius: 4px;
    padding: 6px 12px;
    min-height: 32px;
    font-size: 14px;
    line-height: 20px;
    font-family: 'lato';
}

.btn-blck-in-auta-fcs:hover{
    background-color: rgb(71, 71, 71);
    transition: all 0.2s ease 0s;
}

.btn-blck-non-fcs{
    display: inline-flex;
    -webkit-box-align: center;
    align-items: center;
    -webkit-box-pack: center;
    justify-content: center;
    background-color: rgb(227, 227, 227);
    color: rgb(38, 38, 39);
    position: relative;
    outline: none;
    font-family: inherit;
    border: 0px;
    transition: all 0.4s ease 0s;
    cursor: pointer;
    white-space: nowrap;
    text-decoration: none;
    border-radius: 4px;
    padding: 6px 12px;
    min-height: 32px;
    font-size: 14px;
    line-height: 20px;
}

.btn-blck-non-fcs:hover{
    background-color: rgb(231, 231, 231);
    transition: all 0.2s ease 0s;
    color: black;
}

.modal-content{
    border-radius: 8px;
}

.btn-blck-non-fcs:focus{
    color: #fff;
    background-color: #313335 !important;
    border-color: #3d3e40 !important;
    box-shadow: 0 0 0 0.2rem rgb(68 70 72 / 50%) !important;
}
.btn-blck-non-fcs:active{

color: #fff;
    background-color: #313335 !important;
    border-color: #3d3e40 !important;
    box-shadow: 0 0 0 0.2rem rgb(68 70 72 / 50%) !important;

}


.con-of-temp-lst {
    display: inline-flex;
    width: 100%;
    padding: 5px 10px;
    border-radius: 10px;
    margin-bottom: 10px;
    }

    .con-of-temp-lst:hover {
    background: #f2f2f28a;
    cursor: pointer;
}

.con-of-temp-lst>div {
    width: 50%;
    }

    span.temp-name {
    font-size: 14px;
}

span.crt-data-of-tmp {
    font-size: 10px;
    }
.row{
    margin-left: 0px;
    margin-right: 0px;
}








.btn-primary.focus, .btn-primary:focus{

    color: #fff;
    box-shadow: 0 0 0 0.2rem rgb(105 109 113 / 50%);
    background-color: rgb(38, 38, 39);
    border-color: rgb(38, 38, 39);

}





.err-menu-cls-dsg{

transition:.2s;
  top: auto !important;
    width: fit-content;
    bottom: 10vh !important;
    padding: 10px;
    background: #000000b5;
    font-size: 13px;
    border-radius: 5px;
    z-index: 100;
    color: white !important;
    display: none;
    z-index: 100000000;
}

#cncl-err-msg:hover{


cursor: pointer;


}



.vert-cent-div {
 
  height: min-content;
  text-align: center;
  
  position: absolute;
  top:0;
  bottom: 0;
  left: 0;
  right: 0;
    
  margin: auto;
}


.head-of-act-reached {
    display: flex;
    width: 100%;
    justify-content: center;
    background-color: rgb(255, 255, 255);
    box-shadow: rgb(0 0 0 / 7%) 0px -1px inset;
}

.text-opt-data-show {
    -webkit-box-align: center;
    align-items: center;
    display: flex;
    cursor: pointer;
    text-align: center;
    transition-property: background-color, box-shadow;
    transition-duration: 0.35s;
    transition-timing-function: ease-in-out;
    padding: 13px;
    font-size: 12px;
    line-height: 18px;
    font-weight: 500;
    letter-spacing: 0.1em;
    text-transform: uppercase;
    color: rgb(142 142 144);
    font-family: 'Lato';
    }

   .text-opt-data-show.active{
    color: black;
    border-bottom: 2px solid;
   } 










   .con-of-insight-data {
    padding: 40px 80px;
    background: white;
}

span.head-data {
    display: block;
    line-height: 32px;
    font-family: 'Lato';
    color: rgb(38, 38, 39);
    letter-spacing: 1px;
    font-size: 24px;
    font-weight: 300;
}

    .div-of-10-pad {
    padding: 10px;
}




.btn-of-tab-ovr {
    border: none;
    border-radius: 0px !important;
    font-size: 14px;
    line-height: 20px;
    padding: 8px 20px;
    font-family: 'Lato';
    border-right: 1px solid #585763;
    background: #f2f2f2 !important;
    color: black;
}

    .btn-of-tab-ovr.active {
    background: #585763 !important;
}

.btn-of-tab-ovr.active:hover{
    background: #585763 !important;
    color: white !important;
}

.btn-of-tab-ovr:hover {
    background: #dcd9d9 !important;
   color: black;
}

.con-of-view-data {
    margin-right: 48px;
    }

    span.con-of-tp-data {
    color: rgb(104 104 130);
    opacity: 0.8;
    font-size: 14px;
    font-family: 'Lato';
}
span.con-of-cnt-data-vw {
    color: rgb(38, 38, 39);
    
    box-sizing: border-box;
    -webkit-font-smoothing: antialiased;
    font-weight: 400;
    
    line-height: 44px;
    font-family: 'Lato';
    font-size: 30px;
    }

    .tab-content>.active{
        display: inline-flex;
    }


    .con-of-all-auta-tbl {
    padding: 40px 80px;
}

table#data-tbl-name {
    width: 100%;
    background-color: rgb(255, 255, 255);
    border-radius: 8px;
    box-shadow: rgb(0 0 0 / 6%) 0px 2px 12px, rgb(0 0 0 / 8%) 0px 2px 4px;
    }

    th {
    font-size: 14px;
    font-weight: 400;
    padding: 15px;
    border-bottom: 1px solid rgba(0, 0, 0, 0.07);
    color: rgb(120 120 150);
    font-family: 'Lato';
}

th:hover{
    cursor: pointer;
}

td {
    padding: 20px 10px;
    font-size: 13px;
    border-bottom: 1px solid rgba(0, 0, 0, 0.07);
}
    span.icon-of-tbl {
    padding: 3px 10px;
    font-size: 10px;
    background: #943590;
    color: white;
    border-radius: 10px;
    margin-right: 10px;
    text-transform: uppercase;
    font-weight: 600;
}

#insight{
    display: none;
}


.data-of-field-sum {
    padding: 40px 80px;

    }

    .dt-of-fld-data {
    width: 70%;
    padding: 20px;
    background: #FFF;
    border-radius: 5px;
    margin-bottom: 24px;
    position: relative;
    -webkit-box-shadow: 0 1px 2px 0 rgb(0 0 0 / 4%), 0 2px 8px 0 rgb(0 0 0 / 4%);
    box-shadow: 0 1px 2px 0 rgb(0 0 0 / 4%), 0 2px 8px 0 rgb(0 0 0 / 4%);
}

.dt-abt-field {
    padding: 30px 0px;
    }
    .view-full-automata-act {
    text-align: center;
}
.res-of-abt-fld {
    width: 70%;
    margin: auto;
    overflow: scroll;
    padding-top: 30px;
}

tr:hover{
    cursor: pointer;
}

    .eml-con-dt {
    width: 100%;
    overflow: scroll;
    font-size: 15px;
    color: rgb(69, 79, 90);
    font-family: 'Lato';
    font-weight: 400;
    font-size: 16px;
    opacity: .8;
}

.con-dt-of-act-tm {
    padding-top: 15px;
    font-size: 12px;
    color: #c1bebe;
    padding-bottom: 22px;
    border-bottom: 1px solid #f2f2f2;
    font-family: 'Lato';
    letter-spacing: 1px;
    }

    span.cnt-abt-fld-res {
    font-size: 12px;
    padding: 5px 10px;
    background: #c9e4b9;
    border-radius: 40px;
    float: right;
    color: #2f6b0c;
}

span.name-of-fld {
    font-weight: 600;
    font-family: 'Lato';
    font-size: 15px;
    }

    #summary{
        display: none;
    }
    .container{
        max-width: 80%;
    }

    .head-of-filt {
    padding: 20px 0px;
}

.con-of-all-resp-data {
    width: 100%;
    display: inline-flex;

}

button.filt-btn {
    display: inline-table;
    outline: none;
    border: none;
    background-color: rgb(227, 227, 227);
    color: rgb(38, 38, 39);
    border-radius: 4px;
    padding: 6px 12px;
    min-height: 32px;
    font-size: 14px;
    line-height: 20px;
    font-family: 'Lato';
    }

    .con-of-all-conp-eml {
    width: 40%;
}

.con-of-all-desc-of-eml {
    min-height: 60vh;
    width: 60%;
    margin: 0px 20px;
    padding: 10px;
    border-radius: 10px;
    background: white;
    box-shadow: rgb(0 0 0 / 8%) 0px 2px 4px;
    }
    .head-of-res-cnt {
    padding: 10px;
    border-bottom: 1px solid rgba(0, 0, 0, 0.07);
    border-top: 1px solid rgba(0, 0, 0, 0.07);
    font-size: 11px;
    line-height: 20px;
    color: rgb(12 12 12);
    font-weight: 600;
}


.over-dis-of-con-hist-auta {
    padding: 10px;
    font-size: 14px;
    font-family: 'Lato';
    color: #626077;
    border-bottom: 1px solid #d7d6e4;
    }

    #completed{
        display: none;
    }























































    .dt_of_over_con {
    margin: 0px;
    padding: 0px;
    overflow: hidden;
    background-image: url(../assets/tile.png);
    background-repeat: repeat;
    background-size: 30px 30px;
    background-color: #FBFBFB;
    height: 100%;
}
#navigation {
    height: 71px;
    background-color: #FFF;
    border: 1px solid #E8E8EF;
    width: 100%;
    display: table;
    box-sizing: border-box;
    position: fixed;
    top: 0;
    z-index: 9
}
#back {
    width: 40px;
    height: 40px;
    border-radius: 100px;
    background-color: #F1F4FC;
    text-align: center;
    display: inline-block;
    vertical-align: top;
    margin-top: 12px;
    margin-right: 10px
}
#back img {
    margin-top: 13px;
}
#names {
    display: inline-block;
    vertical-align: top;
}
#title {
    font-family: 'Roboto', sans-serif;
    font-weight: 500;
    font-size: 16px;
    color: #393C44;
    margin-bottom: 0px;
}
#subtitle {
    font-family: 'Roboto', sans-serif;
    color: #808292;
    font-size: 14px;
    margin-top: 5px;
}
#leftside {
    display: inline-block;
    vertical-align: middle;
    margin-left: 20px;
}
#centerswitch {
    position: absolute;
    width: 222px;
    left: 50%;
    margin-left: -111px;
    top: 15px;
}
#leftswitch {
    border: 1px solid #E8E8EF;
    background-color: #FBFBFB;
    width: 111px;
    height: 39px;
    line-height: 39px;
    border-radius: 5px 0px 0px 5px;
    font-family: 'Roboto', sans-serif;
    color: #393C44;
    display: inline-block;
    font-size: 14px;
    text-align: center;
}
#rightswitch {
    font-family: 'Roboto', sans-serif;
    color: #808292;
    border-radius: 0px 5px 5px 0px;
    border: 1px solid #E8E8EF;
    height: 39px;
    width: 102px;
    display: inline-block;
    font-size: 14px;
    line-height: 39px;
    text-align: center;
    margin-left: -5px;
}
#discard {
    font-family: 'Roboto', sans-serif;
    font-weight: 500;
    font-size: 14px;
    color: #A6A6B3;
    width: 95px;
    height: 38px;
    border: 1px solid #E8E8EF;
    border-radius: 5px;
    text-align: center;
    line-height: 38px;
    display: inline-block;
    vertical-align: top;
    transition: all .2s cubic-bezier(.05,.03,.35,1);
}
#discard:hover {
    cursor: pointer;
    opacity: .7;
}
#publish {
    font-family: 'Roboto', sans-serif;
    font-weight: 500;
    font-size: 14px;
    color: #FFF;
    background-color: #217CE8;
    border-radius: 5px;
    width: 143px;
    height: 38px;
    margin-left: 10px;
    display: inline-block;
    vertical-align: top;
    text-align: center;
    line-height: 38px;
    margin-right: 20px;
    transition: all .2s cubic-bezier(.05,.03,.35,1);
}
#publish:hover {
    cursor: pointer;
    opacity: .7;
}
#buttonsright {
    float: right;
    margin-top: 15px;
}
#leftcard {
    width: 363px;
    background-color: #FFF;
    border: 1px solid #E8E8EF;
    box-sizing: border-box;
    padding-top: 85px;
    padding-left: 20px;
    height: 100%;
    position: absolute;
    z-index: 2;
}
#search input {
    width: 318px;
    height: 40px;
    background-color: #FFF;
    border: 1px solid #E8E8EF;
    box-sizing: border-box;
    box-shadow: 0px 2px 8px rgba(34,34,87,0.05);
    border-radius: 5px;
    text-indent: 35px;
    font-family: 'Roboto', sans-serif;
    font-size: 16px;
}
::-webkit-input-placeholder { /* Edge */
  color: #C9C9D5;
}

:-ms-input-placeholder { /* Internet Explorer 10-11 */
  color: #C9C9D5
}

::placeholder {
  color: #C9C9D5;
}
#search img {
    position: absolute; 
    margin-top: 10px;
    width: 18px;
    margin-left: 12px;
}
#header {
    font-size: 20px;
    font-family: 'Roboto', sans-serif;
    font-weight: bold;
    color: #393C44;
}
#subnav {
    border-bottom: 1px solid #E8E8EF;
    width: calc(100% + 20px);
    margin-left: -20px;
    margin-top: 10px;
}
.navdisabled {
    transition: all .3s cubic-bezier(.05,.03,.35,1);
}
.navdisabled:hover {
    cursor: pointer;
    opacity: .5;
}
.navactive {
    color: #393C44!important;
}
#triggers {
    margin-left: 20px;
    font-family: 'Roboto', sans-serif;
    font-weight: 500;
    font-size: 14px;
    text-align: center;
    color: #808292;
    width: calc(88% / 3);
    height: 48px;
    line-height: 48px;
    display: inline-block;
    float: left;
}
.navactive:after {
    display: block;
    content: "";
    width:  100%;
    height: 4px;
    background-color: #217CE8;
    margin-top: -4px;
}
#actions {
    display: inline-block;
    font-family: 'Roboto', sans-serif;
    font-weight: 500;
    color: #808292;
    font-size: 14px;
    height: 48px;
    line-height: 48px;
    width: calc(88% / 3);
    text-align: center;
    float: left;
}
#loggers {
    width: calc(88% / 3);
    display: inline-block;
    font-family: 'Roboto', sans-serif;
    font-weight: 500;
    color: #808292;
    font-size: 14px;
    height: 48px;
    line-height: 48px;
    text-align: center;
}
#footer {
    position: absolute;
    left: 0;
    padding-left: 20px;
    line-height: 40px;
    bottom: 0;
    width: 362px;
    border: 1px solid #E8E8EF;
    height: 67px;
    box-sizing: border-box;
    background-color: #FFF;
    font-family: 'Roboto', sans-serif;
    font-size: 14px;
}
#footer a {
    text-decoration: none;
    color: #393C44;
    transition: all .2s cubic-bezier(.05,.03,.35,1);
}
#footer a:hover {
    opacity: .5;
}
#footer span {
    color: #808292;
}
#footer p {
    display: inline-block;
    color: #808292;
}
#footer img {
    margin-left: 5px;
    margin-right: 5px;
}
.blockelem:first-child {
    margin-top: 20px
}
.blockelem {
    padding-top: 10px;
    width: 318px;
    border: 1px solid transparent;
    transition-property: box-shadow, height;
    transition-duration: .2s;
    transition-timing-function: cubic-bezier(.05,.03,.35,1);
    border-radius: 5px;
    box-shadow: 0px 0px 30px rgba(22, 33, 74, 0);
    box-sizing: border-box;
}
.blockelem:hover {
    box-shadow: 0px 4px 30px rgba(22, 33, 74, 0.08);
    border-radius: 5px;
    background-color: #FFF;
    cursor: pointer;
}
.grabme, .blockico {
    display: inline-block;
}
.grabme {
    margin-top: 10px;
    margin-left: 10px;
    margin-bottom: -14px;
    width: 15px;
}
#blocklist {
    height: calc(100% - 220px);
    overflow: auto;
}
#proplist {
    height: calc(100% - 305px);
    overflow: auto;
    margin-top: -30px;
    padding-top: 30px;
}
.blockin {
    display: inline-block;
    vertical-align: top;
    margin-left: 12px;
}
.blockico {
    width: 36px;
    height: 36px;
    background-color: #F1F4FC;
    border-radius: 5px;
    text-align: center;
    white-space: nowrap;
}
.blockico span {
    height: 100%;
    width: 0px;
    display: inline-block;
    vertical-align: middle;
}
.blockico img {
    vertical-align: middle;
    margin-left: auto;
    margin-right: auto;
    display: inline-block;
}
.blocktext {
    display: inline-block;
    width: 220px;
    vertical-align: top;
    margin-left: 12px
}
.blocktitle {
    margin: 0px!important;
    padding: 0px!important;
    font-family: 'Roboto', sans-serif;
    font-weight: 500;
    font-size: 16px;
    color: #393C44;
}
.blockdesc {
    margin-top: 5px;
    font-family: 'Roboto', sans-serif;
    color: #808292;
    font-size: 14px;
    line-height: 21px;
}
.blockdisabled {
    background-color: #F0F2F9;
    opacity: .5;
}
#closecard {
    position: absolute;
    margin-left: 340px;
    background-color: #FFF;
    border-radius: 0px 5px 5px 0px;
    border-bottom: 1px solid #E8E8EF;
    border-right: 1px solid #E8E8EF;
    border-top: 1px solid #E8E8EF;
    width: 53px;
    height: 53px;
    text-align: center; 
    z-index: 10;
}
#closecard img {
    margin-top: 15px
}
#canvas {
    position: absolute;
    width: calc(100% - 361px);
    height: calc(100% - 71px);
    top: 71px;
    left: 361px;
    z-index: 0;
    overflow: auto;
}
#propwrap {
    position: absolute;
    right: 0;
    top: 0;
    width: 311px;
    height: 100%;
    padding-left: 20px;
    overflow: hidden;
    z-index: -2;
}
#properties {
    position: absolute;
    height: 100%;
    width: 311px;
    background-color: #FFF;
    right: -150px;
    opacity: 0;
    z-index: 2;
    top: 0px;
    box-shadow: -4px 0px 40px rgba(26, 26, 73, 0);
    padding-left: 20px;
    transition: all .25s cubic-bezier(.05,.03,.35,1);
}
.itson {
    z-index: 2!important;
}
.expanded {
    right: 0!important;
    opacity: 1!important;
    box-shadow: -4px 0px 40px rgba(26, 26, 73, 0.05);
        z-index: 2;
}
#header2 {
    font-size: 20px;
    font-family: 'Roboto', sans-serif;
    font-weight: bold;
    color: #393C44;
    margin-top: 101px;
}
#close {
    margin-top: 100px;
    position: absolute;
    right: 20px;
    z-index: 9999;
    transition: all .25s cubic-bezier(.05,.03,.35,1);
}
#close:hover {
    cursor: pointer;
    opacity: .7;
}
#propswitch {
    border-bottom: 1px solid #E8E8EF;
    width: 331px;
    margin-top: 10px;
    margin-left: -20px;
    margin-bottom: 30px;
}
#dataprop {
    font-family: 'Roboto', sans-serif;
    font-weight: 500;
    font-size: 14px;
    text-align: center;
    color: #393C44;
    width: calc(88% / 3);
    height: 48px;
    line-height: 48px;
    display: inline-block;
    float: left;
    margin-left: 20px;
}
#dataprop:after {
    display: block;
    content: "";
    width: 100%;
    height: 4px;
    background-color: #217CE8;
    margin-top: -4px;
}
#alertprop {
    display: inline-block;
    font-family: 'Roboto', sans-serif;
    font-weight: 500;
    color: #808292;
    font-size: 14px;
    height: 48px;
    line-height: 48px;
    width: calc(88% / 3);
    text-align: center;
    float: left;
}
#logsprop {
    width: calc(88% / 3);
    display: inline-block;
    font-family: 'Roboto', sans-serif;
    font-weight: 500;
    color: #808292;
    font-size: 14px;
    height: 48px;
    line-height: 48px;
    text-align: center;
}
.inputlabel {
    font-family: 'Roboto', sans-serif;
    font-size: 14px;
    color: #253134;
}
.dropme {
    background-color: #FFF;
    border-radius: 5px;
    border: 1px solid #E8E8EF;
    box-shadow: 0px 2px 8px rgba(34, 34, 87, 0.05);
    font-family: 'Roboto', sans-serif;
    font-size: 14px;
    color: #253134;
    text-indent: 20px;
    height: 40px;
    line-height: 40px;
    width: 287px;
    margin-bottom: 25px;
}
.dropme img {
    margin-top: 17px;
    float: right;
    margin-right: 15px;
}
.checkus {
    margin-bottom: 10px;
}
.checkus img {
    display: inline-block;
    vertical-align: middle;
}
.checkus p {
    display: inline-block;
    font-family: 'Roboto', sans-serif;
    font-size: 14px;
    vertical-align: middle;
    margin-left: 10px;
}
#divisionthing {
    height: 1px;
    width: 100%;
    background-color: #E8E8EF;
    position: absolute;
    right: 0px;
    bottom: 80;
}
#removeblock {
    border-radius: 5px;
    position: absolute;
    bottom: 20px;
    font-family: 'Roboto', sans-serif;
    font-size: 14px;
    text-align: center;
    width: 287px;
    height: 38px;
    line-height: 38px;
    color: #253134;
    border: 1px solid #E8E8EF;
    transition: all .3s cubic-bezier(.05,.03,.35,1);
}
#removeblock:hover {
    cursor: pointer;
    opacity: .5;
}
.noselect {
  -webkit-touch-callout: none; /* iOS Safari */
    -webkit-user-select: none; /* Safari */
     -khtml-user-select: none; /* Konqueror HTML */
       -moz-user-select: none; /* Old versions of Firefox */
        -ms-user-select: none; /* Internet Explorer/Edge */
            user-select: none; /* Non-prefixed version, currently
                                  supported by Chrome, Opera and Firefox */
}
.blockyname {
    font-family: 'Roboto', sans-serif;
    font-weight: 500;
    color: #253134;
    display: inline-block;
    vertical-align: middle;
    margin-left: 8px;
    font-size: 16px;
}
.blockyleft img {
    display: inline-block;
    vertical-align: middle;
}
.blockyright {
    display: inline-block;
    float: right;
    vertical-align: middle;
    margin-right: 20px;
    margin-top: 10px;
    width: 28px;
    height: 28px;
    border-radius: 5px;
    text-align: center; 
    background-color: #FFF;
    transition: all .3s cubic-bezier(.05,.03,.35,1);
    z-index: 10;
}
.blockyright:hover {
    background-color: #F1F4FC;
    cursor: pointer;
}
.blockyright img {
    margin-top: 12px;
}
.blockyleft {
    display: inline-block;
    margin-left: 20px;
}
.blockydiv {
    width: 100%;
    height: 1px;
    background-color: #E9E9EF;
}
.blockyinfo {
    font-family: 'Roboto', sans-serif;
    font-size: 14px;
    color: #808292;
    margin-top: 15px;
    text-indent: 20px;
    margin-bottom: 20px;
}
.blockyinfo span {
    color: #253134;
    font-weight: 500;
    display: inline-block;
    border-bottom: 1px solid #D3DCEA;
    line-height: 20px;
    text-indent: 0px;
}
.block {
    background-color: #FFF;
    margin-top: 0px!important;
    box-shadow: 0px 4px 30px rgba(22, 33, 74, 0.05);
}
.selectedblock {
    border: 2px solid #217CE8;
    box-shadow: 0px 4px 30px rgba(22, 33, 74, 0.08);
}

@media only screen and (max-width: 832px) {
    #centerswitch {
        display: none;
    }
}
@media only screen and (max-width: 560px) {
    #names {
        display: none;
    }   
}

.res-of-abt-fld.act-comp-main-con {
    margin-bottom: 10px;
    }

    .eml-con-dt.act-of-comp-tbl {
    width: fit-content;
    font-size: 14px;
    background: #efceec;
    padding: 4px 10px;
    border-radius: 5px;
    color: #ab0b9d;
    margin: auto;
    font-weight: 700;
}
.con-dt-of-act-tm.act-tm-of-comp-dt {
    width: fit-content;
    margin: auto;
    margin-top: 3px;
    margin-bottom: 10px;
    border-bottom: 0px;
    background: green;
    padding: 3px 10px;
    border-radius: 10px;
    color: #d9f1d9;
    }

    .end-of-auta-flg {
    text-align: center;
}

.end-of-auta-flg img {
    height: 30px;
    }

    .cp-round:after{
        border-top: solid 3px #564f4e;


    }

    .cp-spinner.cp-round {
    margin-top: 20px;
}
</style>

<script src="http://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
</head>

<body style="
    margin: 0px;
">





<div class="vert-cent-div err-menu-cls-dsg" id="err_msg_dt_trg" style="display: none;">
<span id="con-of-err-msg"></span>
<span class="cls-err-menu" id="cncl-err-msg">
<i class="fal fa-times-circle" style="
    padding: 6px;
"></i>
</span>
</div>


<div class="main-con-of-dash">

    
    <div class="sd-con-ico dsc-inln-flx" style="
">
    
    <div class="sd-hd-con"><img src="https://res.cloudinary.com/heptera/image/upload/v1611850905/landing/open-collective_1_m4opwf.svg" width="" style="
    padding: 2vh
    ">
</div>

<div class="icon-con-of-sd">

    <div class="icon-main-con">
    
    <div class="con-ico" data-bs-toggle="tooltip" data-bs-placement="right" title="DashBoard"><img class="con-of-ico-img" src="https://res.cloudinary.com/heptera/image/upload/v1626278279/automation/window_black_24dp_bgpmiu.svg"></div>

<div class="con-ico" data-bs-toggle="tooltip" data-bs-placement="right" title="Campigns"><img class="con-of-ico-img" src="https://res.cloudinary.com/heptera/image/upload/v1626278281/automation/schedule_send_black_24dp_wybxtb.svg"></div>

<div class="con-ico" data-bs-toggle="tooltip" data-bs-placement="right" title="Studio"><img class="con-of-ico-img" src="https://res.cloudinary.com/heptera/image/upload/v1626278284/automation/camera_black_24dp_ldwdgu.svg"></div>

<div class="con-ico" data-bs-toggle="tooltip" data-bs-placement="right" title="Template"><img class="con-of-ico-img" src="https://res.cloudinary.com/heptera/image/upload/v1626278301/automation/web_black_24dp_kx5cze.svg"></div>
    
    </div>


</div>
        
    
    </div>
    <div class="main-con-of-crm dsc-inln-flx">
        <div class='head-of-dash'>







<div class="dropdown" style="
    height: 8vh;
"> 
    <button class="btn btn-secondary dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" style="
    height: 8vh;
"> 
       <svg width="30" height="30" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" style="color:white;"><path d="M7 7H9V9H7V7Z" fill="currentColor"></path><path d="M11 7H13V9H11V7Z" fill="currentColor"></path><path d="M17 7H15V9H17V7Z" fill="currentColor"></path><path d="M7 11H9V13H7V11Z" fill="currentColor"></path><path d="M13 11H11V13H13V11Z" fill="currentColor"></path><path d="M15 11H17V13H15V11Z" fill="currentColor"></path><path d="M9 15H7V17H9V15Z" fill="currentColor"></path><path d="M11 15H13V17H11V15Z" fill="currentColor"></path><path d="M17 15H15V17H17V15Z" fill="currentColor"></path></svg>
    </button> 
    <div class="dropdown-menu dropdown-menu-right" x-placement="bottom-end" style="position: absolute; transform: translate3d(905px, 53px, 0px); top: 0px; left: 0px; will-change: transform;">
<div class=" dropdown-header noti-title">
<h6 class="text-overflow m-0">admin@auftera.com</h6>
</div>
<button class="dropdown-item comm_up_btn com-for-lnk" data-for-serv="1" data-path-ses="account/" data-target-link="https://account.auftera.com/account/sites/add_sites/">
<svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M6 8C6.74028 8 7.38663 7.5978 7.73244 7H14C15.1046 7 16 7.89543 16 9C16 10.1046 15.1046 11 14 11H10C7.79086 11 6 12.7909 6 15C6 17.2091 7.79086 19 10 19H16.2676C16.6134 19.5978 17.2597 20 18 20C19.1046 20 20 19.1046 20 18C20 16.8954 19.1046 16 18 16C17.2597 16 16.6134 16.4022 16.2676 17H10C8.89543 17 8 16.1046 8 15C8 13.8954 8.89543 13 10 13H14C16.2091 13 18 11.2091 18 9C18 6.79086 16.2091 5 14 5H7.73244C7.38663 4.4022 6.74028 4 6 4C4.89543 4 4 4.89543 4 6C4 7.10457 4.89543 8 6 8Z" fill="currentColor"></path></svg>
<span class="padding-left:10px;">
Connected App </span></button>
<button class="dropdown-item comm_up_btn com-for-lnk" data-for-serv="1" data-path-ses="account/" data-target-link="https://account.auftera.com/account/sender/add_sender/">
<svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" clip-rule="evenodd" d="M16 9C16 11.2091 14.2091 13 12 13C9.79086 13 8 11.2091 8 9C8 6.79086 9.79086 5 12 5C14.2091 5 16 6.79086 16 9ZM14 9C14 10.1046 13.1046 11 12 11C10.8954 11 10 10.1046 10 9C10 7.89543 10.8954 7 12 7C13.1046 7 14 7.89543 14 9Z" fill="currentColor"></path><path fill-rule="evenodd" clip-rule="evenodd" d="M12 1C5.92487 1 1 5.92487 1 12C1 18.0751 5.92487 23 12 23C18.0751 23 23 18.0751 23 12C23 5.92487 18.0751 1 12 1ZM3 12C3 14.0902 3.71255 16.014 4.90798 17.5417C6.55245 15.3889 9.14627 14 12.0645 14C14.9448 14 17.5092 15.3531 19.1565 17.4583C20.313 15.9443 21 14.0524 21 12C21 7.02944 16.9706 3 12 3C7.02944 3 3 7.02944 3 12ZM12 21C9.84977 21 7.87565 20.2459 6.32767 18.9878C7.59352 17.1812 9.69106 16 12.0645 16C14.4084 16 16.4833 17.1521 17.7538 18.9209C16.1939 20.2191 14.1881 21 12 21Z" fill="currentColor"></path></svg>
<span class="padding-left:10px;">
Sender Profile</span></button>
<button class="dropdown-item comm_up_btn com-for-lnk" data-for-serv="1" data-path-ses="account/" data-target-link="https://account.auftera.com/account/smtp/add_smtp/">
<svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M9 6C8.44772 6 8 6.44772 8 7C8 7.55228 8.44772 8 9 8H15C15.5523 8 16 7.55228 16 7C16 6.44772 15.5523 6 15 6H9Z" fill="currentColor"></path><path d="M9 10C8.44772 10 8 10.4477 8 11C8 11.5523 8.44772 12 9 12H15C15.5523 12 16 11.5523 16 11C16 10.4477 15.5523 10 15 10H9Z" fill="currentColor"></path><path d="M13 17C13 17.5523 12.5523 18 12 18C11.4477 18 11 17.5523 11 17C11 16.4477 11.4477 16 12 16C12.5523 16 13 16.4477 13 17Z" fill="currentColor"></path><path fill-rule="evenodd" clip-rule="evenodd" d="M4 5C4 3.34315 5.34315 2 7 2H17C18.6569 2 20 3.34315 20 5V19C20 20.6569 18.6569 22 17 22H7C5.34315 22 4 20.6569 4 19V5ZM7 4H17C17.5523 4 18 4.44772 18 5V19C18 19.5523 17.5523 20 17 20H7C6.44772 20 6 19.5523 6 19V5C6 4.44772 6.44771 4 7 4Z" fill="currentColor"></path></svg>
<span class="padding-left:10px;">
SMTP Server </span></button>
<button class="dropdown-item comm_up_btn com-for-lnk" data-for-serv="0" data-path-ses="contact/" data-target-link="https://contact.auftera.com/contact/emb/">
<svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" clip-rule="evenodd" d="M9 3H3V9H5V5H9V3ZM3 21V15H5V19H9V21H3ZM15 3V5H19V9H21V3H15ZM19 15H21V21H15V19H19V15ZM7 7H11V11H7V7ZM7 13H11V17H7V13ZM17 7H13V11H17V7ZM13 13H17V17H13V13Z" fill="currentColor"></path></svg><span class="padding-left:10px;">
Integration </span></button>
<button class="dropdown-item comm_up_btn com-for-lnk" data-for-serv="1" data-path-ses="dev/" data-target-link="https://dev.auftera.com/dev/">
<svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M4 14V20H10V18H6V14H4Z" fill="currentColor"></path><path fill-rule="evenodd" clip-rule="evenodd" d="M9 9V15H15V9H9ZM13 11H11V13H13V11Z" fill="currentColor"></path><path d="M4 10V4H10V6H6V10H4Z" fill="currentColor"></path><path d="M20 10V4H14V6H18V10H20Z" fill="currentColor"></path><path d="M20 14V20H14V18H18V14H20Z" fill="currentColor"></path></svg>
<span class="padding-left:10px;">
API</span></button>
<div class="dropdown-divider"></div>
<button class="dropdown-item comm_up_btn" data-for-serv="1" data-target-link="http://account.auftera.com/logout/">
<svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" clip-rule="evenodd" d="M11 19V22H13V19H14C16.2091 19 18 17.2091 18 15C18 12.7909 16.2091 11 14 11H13V7H15V9H17V5H13V2H11V5H10C7.79086 5 6 6.79086 6 9C6 11.2091 7.79086 13 10 13H11V17H9V15H7V19H11ZM13 17H14C15.1046 17 16 16.1046 16 15C16 13.8954 15.1046 13 14 13H13V17ZM11 11V7H10C8.89543 7 8 7.89543 8 9C8 10.1046 8.89543 11 10 11H11Z" fill="currentColor"></path></svg>
<span class="padding-left:10px;">
Plan</span></button>
<button class="dropdown-item comm_up_btn com" data-for-serv="1" data-target-link="http://account.auftera.com/logout/">
<svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M8.51428 20H4.51428C3.40971 20 2.51428 19.1046 2.51428 18V6C2.51428 4.89543 3.40971 4 4.51428 4H8.51428V6H4.51428V18H8.51428V20Z" fill="currentColor"></path><path d="M13.8418 17.385L15.262 15.9768L11.3428 12.0242L20.4857 12.0242C21.038 12.0242 21.4857 11.5765 21.4857 11.0242C21.4857 10.4719 21.038 10.0242 20.4857 10.0242L11.3236 10.0242L15.304 6.0774L13.8958 4.6572L7.5049 10.9941L13.8418 17.385Z" fill="currentColor"></path></svg>
<span class="padding-left:10px;">
Log Out</span></button>
</div>
 </div>









        </div>

     


       
    
 <div class="main-auta-con">
    
    
<div class="head-of-act-reached">

    <div class="text-opt-data-show trg-dif-dis" data-trg-show="insight" >Insight</div>
    <div class="text-opt-data-show trg-dif-dis" data-trg-show="summary">Summary</div>
    <div class="text-opt-data-show trg-dif-dis" data-trg-show="completed">Completed</div>



</div>



    
    
</div>



<div id="insight">



    <div class="con-of-insight-data">
    <div class="head-of-line">

        <span class="head-data">Automation Insight</span>
<div class="div-of-10-pad"></div>
<ul class="nav nav-pills mb-3" id="pills-tab" role="tablist" style="
">
  <li class="nav-item" role="presentation">
    <button class="nav-link active btn-of-tab-ovr" id="pills-home-tab" data-bs-toggle="pill" data-bs-target="#pills-all" type="button" role="tab" aria-controls="pills-home" aria-selected="true" style="
    border-radius: 5px 0px 0px 5px !important;
">All Days</button>
  </li>
  <li class="nav-item" role="presentation">
    <button class="nav-link btn-of-tab-ovr" id="pills-profile-tab " data-bs-toggle="pill" data-bs-target="#pills-today" type="button" role="tab" aria-controls="pills-profile" aria-selected="false">Today</button>
  </li>
  <li class="nav-item" role="presentation" style="
">
    <button class="nav-link btn-of-tab-ovr" id="pills-contact-tab" data-bs-toggle="pill" data-bs-target="#pills-yest" type="button" role="tab" aria-controls="pills-contact" aria-selected="false" style="
    border-radius: 0px 10px 10px 0px !important;
    border-right: 0px;
">Yeaterday</button>
  </li>
</ul>
<div class="tab-content" id="pills-tabContent">
  <div class="tab-pane fade act-of-tab-fld active show" id="pills-all" role="tabpanel" aria-labelledby="pills-profile-tab">





 <div class="con-of-view-data"><span class="con-of-tp-data"  >Start</span><br><span class="con-of-cnt-data-vw" id="all-str-cnt"><div class="cp-spinner cp-round"></div></span></div>

<div class="con-of-view-data"><span class="con-of-tp-data" >On way</span><br><span class="con-of-cnt-data-vw" id="all-on-cnt"><div class="cp-spinner cp-round"></div></span></div>


<div class="con-of-view-data"><span class="con-of-tp-data" >Completed</span><br><span class="con-of-cnt-data-vw" id='all-comp-cnt'><div class="cp-spinner cp-round"></div></span></div>


<div class="con-of-view-data"><span class="con-of-tp-data" >Estimated Time</span><br><span class="con-of-cnt-data-vw" id="all-tm-cnt"><div class="cp-spinner cp-round"></div></span></div>




  </div>
  <div class="tab-pane fade act-of-tab-fld" id="pills-today" role="tabpanel" aria-labelledby="pills-profile-tab">





 <div class="con-of-view-data"><span class="con-of-tp-data" >Start</span><br><span class="con-of-cnt-data-vw" id='today-str-cnt'><div class="cp-spinner cp-round"></div></span></div>

<div class="con-of-view-data"><span class="con-of-tp-data" >On way</span><br><span class="con-of-cnt-data-vw" id='today-on-cnt'><div class="cp-spinner cp-round"></div></span></div>


<div class="con-of-view-data"><span class="con-of-tp-data" >Completed</span><br><span class="con-of-cnt-data-vw" id='today-comp-cnt'><div class="cp-spinner cp-round"></div></span></div>


<div class="con-of-view-data"><span class="con-of-tp-data" >Estimated Time</span><br><span class="con-of-cnt-data-vw" id='today-tm-cnt'><div class="cp-spinner cp-round"></div></span></div>




  </div>
  <div class="tab-pane fade act-of-tab-fld" id="pills-yest" role="tabpanel" aria-labelledby="pills-contact-tab">





 <div class="con-of-view-data"><span class="con-of-tp-data" >Start</span><br><span class="con-of-cnt-data-vw" id="yest-str-cnt"><div class="cp-spinner cp-round"></div></span></div>

<div class="con-of-view-data"><span class="con-of-tp-data" >On way</span><br><span class="con-of-cnt-data-vw" id="yest-on-cnt"><div class="cp-spinner cp-round"></div></span></div>


<div class="con-of-view-data"><span class="con-of-tp-data" >Completed</span><br><span class="con-of-cnt-data-vw" id="yest-comp-cnt"><div class="cp-spinner cp-round"></div></span></div>


<div class="con-of-view-data"><span class="con-of-tp-data" >Estimated Time</span><br><span class="con-of-cnt-data-vw" id="yest-tm-cnt"><div class="cp-spinner cp-round"></div></span></div>








  </div>
</div>


    </div>







</div>




<div class="con-of-all-auta-tbl">
    
    <div class="dt-of-tbl-con">
        
        <span class="head-data">Automation By Email</span>
    
    
 </div><div class="all-tbl-data" style="
    padding-top: 30px;
">

<table id="data-tbl-name">
 <tr>
    <th>Block Type

    <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="currentColor" class="bi bi-sort-alpha-down" viewBox="0 0 16 16" style="
    margin-left: 10px;
    fill: black;
    padding: 2px;
    background: #f2f2f2;
    border-radius: 2px;
">
  <path fill-rule="evenodd" d="M10.082 5.629 9.664 7H8.598l1.789-5.332h1.234L13.402 7h-1.12l-.419-1.371h-1.781zm1.57-.785L11 2.687h-.047l-.652 2.157h1.351z"></path>
  <path d="M12.96 14H9.028v-.691l2.579-3.72v-.054H9.098v-.867h3.785v.691l-2.567 3.72v.054h2.645V14zM4.5 2.5a.5.5 0 0 0-1 0v9.793l-1.146-1.147a.5.5 0 0 0-.708.708l2 1.999.007.007a.497.497 0 0 0 .7-.006l2-2a.5.5 0 0 0-.707-.708L4.5 12.293V2.5z"></path>
</svg>


</th>
    <th>Reached

    
    <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="currentColor" class="bi bi-sort-alpha-down" viewBox="0 0 16 16" style="
    margin-left: 10px;
    fill: black;
    padding: 2px;
    background: #f2f2f2;
    border-radius: 2px;
">
  <path fill-rule="evenodd" d="M10.082 5.629 9.664 7H8.598l1.789-5.332h1.234L13.402 7h-1.12l-.419-1.371h-1.781zm1.57-.785L11 2.687h-.047l-.652 2.157h1.351z"></path>
  <path d="M12.96 14H9.028v-.691l2.579-3.72v-.054H9.098v-.867h3.785v.691l-2.567 3.72v.054h2.645V14zM4.5 2.5a.5.5 0 0 0-1 0v9.793l-1.146-1.147a.5.5 0 0 0-.708.708l2 1.999.007.007a.497.497 0 0 0 .7-.006l2-2a.5.5 0 0 0-.707-.708L4.5 12.293V2.5z"></path>
</svg>

</th>
    <th>Completed


    <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="currentColor" class="bi bi-sort-alpha-down" viewBox="0 0 16 16" style="
    margin-left: 10px;
    fill: black;
    padding: 2px;
    background: #f2f2f2;
    border-radius: 2px;
">
  <path fill-rule="evenodd" d="M10.082 5.629 9.664 7H8.598l1.789-5.332h1.234L13.402 7h-1.12l-.419-1.371h-1.781zm1.57-.785L11 2.687h-.047l-.652 2.157h1.351z"></path>
  <path d="M12.96 14H9.028v-.691l2.579-3.72v-.054H9.098v-.867h3.785v.691l-2.567 3.72v.054h2.645V14zM4.5 2.5a.5.5 0 0 0-1 0v9.793l-1.146-1.147a.5.5 0 0 0-.708.708l2 1.999.007.007a.497.497 0 0 0 .7-.006l2-2a.5.5 0 0 0-.707-.708L4.5 12.293V2.5z"></path>
</svg>

</th>
  </tr>

   <tbody id="insight_dyna_data">
  <tr>
    <td><span class="icon-of-tbl">Add Contact</span>Alfreds Futterkiste</td>
    <td>Maria Anders</td>
    <td>Germany</td>
  </tr>
    
    </tbody></table>
    

</div>

</div>


</div>



<div id="summary">



<div class="con-of-insight-data" style="background:none">
    <div class="head-of-line">

        <span class="head-data">Automation Summary</span>

    </div>
</div>

<div class="data-of-field-sum" id="sum-con-dis-unq">



</div>

</div>

 

 <div id="completed">

<div class="container">


<div class="head-of-filt">

    <button class="filt-btn">Completed time 

<svg aria-hidden="true" focusable="false" data-prefix="fas" data-icon="sort" class="svg-inline--fa fa-sort fa-w-10" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 320 512" style="
    height: 16px;
    margin-left: 8px;
"><path fill="currentColor" d="M41 288h238c21.4 0 32.1 25.9 17 41L177 448c-9.4 9.4-24.6 9.4-33.9 0L24 329c-15.1-15.1-4.4-41 17-41zm255-105L177 64c-9.4-9.4-24.6-9.4-33.9 0L24 183c-15.1 15.1-4.4 41 17 41h238c21.4 0 32.1-25.9 17-41z"></path></svg></button>

<button class="filt-btn">Email Address
<svg aria-hidden="true" focusable="false" data-prefix="fas" data-icon="sort" class="svg-inline--fa fa-sort fa-w-10" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 320 512" style="
    height: 16px;
    margin-left: 8px;
"><path fill="currentColor" d="M41 288h238c21.4 0 32.1 25.9 17 41L177 448c-9.4 9.4-24.6 9.4-33.9 0L24 329c-15.1-15.1-4.4-41 17-41zm255-105L177 64c-9.4-9.4-24.6-9.4-33.9 0L24 183c-15.1 15.1-4.4 41 17 41h238c21.4 0 32.1-25.9 17-41z"></path></svg></button>

     

</div>

<div class="con-of-all-resp-data">


    <div class="con-of-all-conp-eml">
    
    <div class="head-of-res-cnt">
    <span id="dt-cnt-of-all-con-comp"></span> Contact Completed
    </div>

    <table id="myTable" style="
    width: 100%;
">
  <tbody id="tbl-bd-of-comp">
  
    </tbody></table>
    


</div>
    <div class="con-of-all-desc-of-eml">

    
    <div class="over-dis-of-con-hist-auta">
    
    <div class="head-of-ovr-dis-flow">
    
        <span class="res-date-con" id="date-of-comp-auta-con">12 Jul 2020 11:30</span>
        
    
    </div>
    
    
    
    </div>

<div class="flow-act-con" id="auta_comp_dis_data">
        
        
        





    
    
    
    
    
    
    
    </div>





</div>




</div>

</div>



</div>














    
    </div>




   


</div>







<div class="modal" id="exampleModalLive" tabindex="-1" aria-labelledby="exampleModalLiveLabel" style="display: none;" aria-hidden="true">
  <div class="modal-dialog" style="
    margin: 0px;
    min-width: 100%;
    min-height: 100vh;
">
    <div class="modal-content" style="
    height: 100vh;
    border-radius: 0px;
">
      <div class="modal-header" style="
    border-bottom: none;
">
        <h5 class="modal-title new-crt-head" id="exampleModalLongTitle" style="
    color: black;
    font-size: 15px;
">Contact Automation Path</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <p>Woohoo, you're reading this text in a modal!</p>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        <button type="button" class="btn btn-primary">Save changes</button>
      </div>
    </div>
  </div>
</div>








</body></html>






<script type="text/javascript">


var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'))
var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
  return new bootstrap.Tooltip(tooltipTriggerEl)
})

auta_id='bmV3LXJlbmFtZQ==';

$(document).on('click','.trg-dif-dis',function(){

act_attr=$(this).attr('data-trg-show');

dis_blck_of_wich_fold(act_attr);

})


function dis_blck_of_wich_fold(act_attr){

    $('.trg-dif-dis').map(function() {


$(this).removeClass('active');

$("#"+$(this).attr('data-trg-show')).css('display','none');

    })

$("div[data-trg-show="+act_attr+"]").addClass("active");

$("#"+act_attr).css('display','block');

if(act_attr=="insight"){


init_insight_data();

}
}


json_for_inter={};


function insert(str, index, value) {
    return str.substr(0, index) + value + str.substr(index);
}



function init_date_in_val(date_str){


date_ret=date_str;

date_ret=insert(date_ret,4,"-");
date_ret=insert(date_ret,7,"-");

date_ret=insert(date_ret,10," ");

date_ret=insert(date_ret,13,":");
date_ret=insert(date_ret,16,":");

return date_ret.split(" ")[0];


}


function get_avg_tm_hr(low_date,high_date){




low=new Date(init_date_in_val(low_date));
high=new Date(init_date_in_val(high_date));



return (high-low);


}

function msToTime(duration) {
  var milliseconds = parseInt((duration % 1000) / 100),
    seconds = Math.floor((duration / 1000) % 60),
    minutes = Math.floor((duration / (1000 * 60)) % 60),
    hours = Math.floor((duration / (1000 * 60 * 60)) % 24);

  hours = (hours < 10) ? "0" + hours : hours;
  minutes = (minutes < 10) ? "0" + minutes : minutes;
  seconds = (seconds < 10) ? "0" + seconds : seconds;

  return hours + ":" + minutes + ":" + seconds + "." + milliseconds;
}

function init_dash_insight_data(data){

data_len=data.length;


com_cnt_auta=parseInt(data[data_len-1]['completed']);
reach_str_cnt=parseInt(data[0]['reached']);
reached_con=reach_str_cnt+com_cnt_auta;


$("#all-str-cnt").html(reached_con);
$("#all-on-cnt").html(reached_con-com_cnt_auta);
$("#all-comp-cnt").html(com_cnt_auta);


console.log(data[data_len-1]['avg_tm']);
console.log(data[0]['avg_tm']);
$("#all-tm-cnt").html(msToTime(get_avg_tm_hr(data[data_len-1]['avg_tm'],data[0]['avg_tm'])));




str_app="";



for (var i = 0; i < data.length; i++) {
    
    console.log(json_for_inter[data[i]['act_tp']].name);
str_app+='<tr> <td><span class="icon-of-tbl">'+json_for_inter[data[i]['act_tp']].name+'</span></td> <td>'+data[i]['reached']+'</td> <td>'+data[i]['completed']+'</td> </tr>';

};


$("#insight_dyna_data").html(str_app);

}


function init_data_of_td_yst(today,yest){


data=today;
data_len=data.length;

console.log(today);

if(today.length==0){


    com_cnt_auta=0;
reach_str_cnt=0;
reached_con=reach_str_cnt+com_cnt_auta;

tm_inter=0;



}else{


com_cnt_auta=parseInt(data[data_len-1]['completed']);
reach_str_cnt=parseInt(data[0]['reached']);
reached_con=reach_str_cnt+com_cnt_auta;

tm_inter=msToTime(get_avg_tm_hr(data[data_len-1]['comp_tm'],data[0]['reached_tm']));

    
}

$("#today-str-cnt").html(reached_con);
$("#today-on-cnt").html(reached_con-com_cnt_auta);
$("#today-comp-cnt").html(com_cnt_auta);

$("#today-tm-cnt").html(tm_inter);

console.log(yest);

if(yest.length==0){


console.log("todat bi;");
com_cnt_auta=0;
reach_str_cnt=0;
reached_con=reach_str_cnt+com_cnt_auta;

tm_inter=0;



}else{



  
  data=yest;
data_len=data.length;
com_cnt_auta=parseInt(data[data_len-1]['completed']);
reach_str_cnt=parseInt(data[0]['reached']);
reached_con=reach_str_cnt+com_cnt_auta;

tm_inter=msToTime(get_avg_tm_hr(data[data_len-1]['comp_tm'],data[0]['reached_tm']));

    
}

$("#yest-str-cnt").html(reached_con);
$("#yest-on-cnt").html(reached_con-com_cnt_auta);
$("#yest-comp-cnt").html(com_cnt_auta);

$("#yest-tm-cnt").html(tm_inter);


}

function init_insight_data(){



$.ajax({
                url : "./ajaxfile/get_insight_data.php?auta_id="+auta_id,
                type: "GET"
        }).done(function(response){ 


jsn_dec_data=JSON.parse(response);

console.log(jsn_dec_data);

init_dash_insight_data(jsn_dec_data.data);


init_data_of_td_yst(jsn_dec_data.today_cnt,jsn_dec_data.yest_cnt);


        })


}




function init_json_interpreter(){


    $.getJSON("./jsonfile/json_for_blck_inter.json", function(data){

        json_for_inter=data;

    })
}


function timeSince(date) {

  var seconds = Math.floor((new Date() - date) / 1000);

  var interval = seconds / 31536000;

  if (interval > 1) {
    return Math.floor(interval) + " years";
  }
  interval = seconds / 2592000;
  if (interval > 1) {
    return Math.floor(interval) + " months";
  }
  interval = seconds / 86400;
  if (interval > 1) {
    return Math.floor(interval) + " days";
  }
  interval = seconds / 3600;
  if (interval > 1) {
    return Math.floor(interval) + " hours";
  }
  interval = seconds / 60;
  if (interval > 1) {
    return Math.floor(interval) + " minutes";
  }
  return Math.floor(seconds) + " seconds";
}


function init_str_data_summary_tbl(data,trg_name){

    str_app="";

    for(const val of data){

str_app+='<div class="dt-of-fld-data"> <div class="field-dt-meta"> <span class="icon-of-tbl" style=" padding: 8px 12px; ">'+trg_name+'</span><span class="name-of-fld">'+val['email']+'</span><br> <div class="div-of-10-pad"></div> <span class="cnt-abt-fld-res">'+val['res_cnt']+' responses</span> </div> <div class="dt-abt-field"> <div class="res-of-abt-fld"> <div class="eml-con-dt">'+trg_name+'</div> <div class="con-dt-of-act-tm">'+timeSince(new Date(val['act_date']))+' ago</div> </div> </div> <div class="view-full-automata-act"> <button type="button" class="btn btn-primary btn-blck-in-auta-fcs vie_comp_step_of_con" >View Completed Steps</button> </div> </div>';
    
        }


        $("#sum-con-dis-unq").html(str_app);


}


function init_summary_data(){



$.ajax({
                url : "./ajaxfile/get_summary_data.php?auta_id="+auta_id,
                type: "GET"
        }).done(function(response){ 

jsn_dec_data=JSON.parse(response);




init_str_data_summary_tbl(jsn_dec_data.data,json_for_inter[jsn_dec_data['trigger']['trg_tp']].name);


        })


}


function dis_comp_data_on_dash(arr_data){


    console.log(arr_data);

data_len=arr_data.length;
str_of_comp_tb="";

for(const val of arr_data){

str_of_comp_tb+='<tr class="trg-of-opn-con-hist" data-trg-con-id="'+val['con_id']+'"> <td>'+timeSince(new Date(val['act_date']))+'</td> <td><div class="tbl-eml-ovr-cont">'+val['email']+'</div></td> </tr>';

}



$(".trg-of-opn-con-hist").css("color","rgb(3, 108, 140)");
$(".trg-of-opn-con-hist").css("background","rgb(230, 243, 247)");


opn_auta_hist_for_con(arr_data[0]['con_id']);

$("#dt-cnt-of-all-con-comp").html(arr_data.length);
$("#tbl-bd-of-comp").html(str_of_comp_tb);

}


function init_dis_data_of_con_comp(jsn_data){


str_app="";
for(const val of jsn_data){



str_app+='<div class="res-of-abt-fld act-comp-main-con"> <div class="eml-con-dt act-of-comp-tbl" style=" text-align: center; ">'+json_for_inter[val['act_tp']].name+'</div> <div class="con-dt-of-act-tm act-tm-of-comp-dt" style=" text-align: center; ">'+timeSince(new Date(val['act_date']))+' ago</div> </div>';

comp_date=timeSince(new Date(val['act_date']))+' ago';

}






$("#date-of-comp-auta-con").html(comp_date);

str_app+='<div class="end-of-auta-flg"> <img src="https://res.cloudinary.com/heptera/image/upload/v1626848149/automation/flag_uxwr1o.png"> </div>';

$("#auta_comp_dis_data").html(str_app);

}


function opn_auta_hist_for_con(con_id){



$('.trg-of-opn-con-hist').map(function(){

$(this).css("color","#22262a");
$(this).css("background","#fafafa");


})


$("tr[data-trg-con-id='"+con_id+"']").css("color","rgb(3, 108, 140)");
$("tr[data-trg-con-id='"+con_id+"']").css("background","rgb(230, 243, 247)");


$.ajax({
                url : "./ajaxfile/get_auta_abt_con.php?auta_id="+auta_id+"&con_id="+con_id,
                type: "GET"
        }).done(function(response){ 


init_dis_data_of_con_comp(JSON.parse(response));


        })




}


$(document).on('click','.trg-of-opn-con-hist',function(){




opn_auta_hist_for_con($(this).attr("data-trg-con-id"));


})


function init_complete_data(){


$.ajax({
                url : "./ajaxfile/get_complete_data.php?auta_id="+auta_id,
                type: "GET"
        }).done(function(response){ 

console.log(response);
jsn_dec_data=JSON.parse(response);



dis_comp_data_on_dash(jsn_dec_data);


        })

}

$(document).on('click','.vie_comp_step_of_con',function(){

dis_blck_of_wich_fold("completed");


})


$(document).ready(function(){


dis_blck_of_wich_fold("insight");

init_json_interpreter();



init_summary_data();


})




init_complete_data();













</script>