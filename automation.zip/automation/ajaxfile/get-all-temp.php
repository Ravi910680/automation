<?php
session_start();

$id=$_SESSION['id'];
require("../create/confige/auta_conf.php");




function select_query($conn,$sel_query){


	$ret_arr=array();

$result = $conn->query($sel_query);

if ($result->num_rows > 0) {
  // output data of each row
  while($row = $result->fetch_assoc()) {
    

    array_push($ret_arr,$row);
  }
}

return $ret_arr;

}



$sel_query="select * from auta_temp where usr_id='$id'";

print_r(json_encode(select_query($auta_conn,$sel_query)));

 

?>