<?php

session_start();









function isrt_query_db($conn,$isrt_query){


if($conn->query($isrt_query)){

return 1;

}else{
	return $conn->error;
}


}

$id=$_SESSION['id'];
require("../create/confige/auta_conf.php");



$temp_id=$_POST['temp_id'];


$query = "DELETE FROM auta_temp WHERE usr_id='$id' and temp_id='$temp_id'";


if(isrt_query_db($auta_conn,$query)==1){


echo 1;
}else{

echo 0;

}


?>