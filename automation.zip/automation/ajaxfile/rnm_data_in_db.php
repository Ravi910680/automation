<?php

session_start();




function isrt_query_db($conn,$isrt_query){


if($conn->query($isrt_query)){

return 1;

}else{
	return $conn->error;
}


}

require("../create/confige/auta_conf.php");

$id=$_SESSION['id'];

$old_name=$_POST['old_name'];
$new_name=$_POST['new_name'];


$source_old_name="../create/save_auta/".$id."#".$old_name.".html";
$dest_new_name="../create/save_auta/".$id."#".base64_encode($new_name).".html";

$old_chg_name=base64_decode($old_name);






if(copy($source_old_name, $dest_new_name)){
unlink($source_old_name);

$query="update auta_name set auta_name='$new_name' where usr_id='$id' and auta_name='$old_chg_name'";

if(isrt_query_db($auta_conn,$query)==1){

echo 1;

}else{

	echo 0;
}


}else{

echo 0;

}






?>