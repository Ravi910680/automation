<?php

session_start();




function isrt_query_db($conn,$isrt_query){


if($conn->query($isrt_query)){

return 1;

}else{
	return $conn->error;
}


}

require("../create/confige/auta_conf.php");

$id=$_SESSION['id'];

$auta_name=$_POST['auta_name'];


$tables = array("auta_act","auta_flow","auta_trg");
foreach($tables as $table) {
  $query = "DELETE FROM $table WHERE usr_id='$id' and auta_name='$auta_name'";
  isrt_query_db($auta_conn,$query);
}

echo 1;


?>