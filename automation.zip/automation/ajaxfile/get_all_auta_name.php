<?php
session_start();

error_reporting(0);

$id=$_SESSION['id'];



function select_query($conn,$sel_query){


	$ret_arr=array();

$result = $conn->query($sel_query);

if ($result->num_rows > 0) {
  // output data of each row
  while($row = $result->fetch_assoc()) {
    

    array_push($ret_arr,$row);
  }
}

return $ret_arr;

}



require("../create/confige/auta_conf.php");


$res_arra=array();

$sel_query="select * from auta_name where usr_id='$id'";

$data_of_all=select_query($auta_conn,$sel_query);

foreach ($data_of_all as $key => $value) {

	$loc_arr=array();
	
	$usr_id=$value['usr_id'];

	
	$auta_name_def=base64_encode($value['auta_name']);

$loc_arr['status']=0;

$sel_query="select * from auta_trg where usr_id='$usr_id' and auta_name='$auta_name_def'";



$result = $auta_conn->query($sel_query);



if($result->num_rows>0){



	$loc_arr['status']=1;
}


$sel_query="select DISTINCT con_id where usr_id='$usr_id' and auta_name='$auta_name_def'";



	$result = $auta_conn->query($sel_query);


$num_of_cnt=$result->num_rows;

if($num_of_cnt==null){
$num_of_cnt=0;

}
$loc_arr['auta_name']=base64_decode($auta_name_def);
$loc_arr['cnt_res']=$num_of_cnt;

array_push($res_arra, $loc_arr);



}

print_r(json_encode($res_arra));


?>